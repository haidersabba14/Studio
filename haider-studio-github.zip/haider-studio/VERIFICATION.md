# تقرير التحقق / Verification

## النتائج الحالية

- اجتازت أداة تجهيز الملفات والتحقق من المحتوى 20 اختبارًا.
- اجتاز الموقع 14 مجموعة اختبارات متصفح، تشمل البحث والتصفية واللغتين والمسودات والنسخ والتنقل والتنزيل والإشعارات والتواصل.
- اجتازت اللوحة المحلية 6 مجموعات اختبارات: سبع ضغطات والرمز الصحيح والخاطئ، حفظ النصوص وتطبيقها، العزل بين المتصفحات، الاستعادة، استيراد وتصدير JSON، ورفض إدخال HTML كمحتوى تنفيذي أو بيانات تنزيل مزوّرة.
- نجحت 3 فحوص مركّزة بعد الإصلاحات الأخيرة، للتحقق من شريط التنقل الثابت، والتنقل الطبيعي من صفحات التطبيقات، وحالات التخزين والقفل.
- فُحصت مقاسات 320 و360 و390 و580 و768 و800 و1024 و1440 بالعربية والإنجليزية دون تجاوز أفقي أو قصّ للأزرار.
- فُحص القفل بعد الإغلاق وإعادة التحميل ومغادرة الصفحة، وتركيز لوحة المفاتيح على الهاتف والحاسوب.

## الملف الأصلي

ملف `downloads/HaiderStudio.ipa` مرفق دون تعديل. الإصدار `1.0.0`، البناء `1`، الحد الأدنى iOS `17.0`، المعرّف `com.haiderstudio.ultimate`، وعائلة الجهاز iPhone `[1]`.

حجمه الحقيقي `1,644,751` بايت، وبصمته:

```text
6c004d1e9eada071c367515102b4254a1fe1b60d39ce27bdc58bbdf0541ae759
```

نُزّل هذا الملف عبر زر الموقع في المتصفح، وطابق الملف الأصلي بالحجم وبصمة SHA-256. توجد نسخته نفسها في مصدر المشروع وناتج النشر. تظهر نسختا التطبيق داخل قسم المونتاج؛ نسخة iOS متاحة ونسخة Android «قريبًا». لم يُرفق ملف APK، ولا يوجد له رابط تنزيل فعّال أو رقم إصدار مزعوم.

## اللوحة والنشر

المدخل في الصفحة الرئيسية: 7 ضغطات متتالية على شعار شريط التنقل ثم `8181`. اللوحة تعدّل نصوصًا عامة فقط وتحفظها في المتصفح. للنشر للجميع، صدّر `studio-content.json` واستبدل به `assets/studio-content.json` ثم أعد البناء والنشر.

هذه بوابة محلية وليست مصادقة آمنة على خادم؛ الرمز موجود في JavaScript العام. لا تستطيع اللوحة تغيير الملفات الأصلية أو الإصدارات أو الأحجام أو البصمات أو روابط التنزيل.

## حدود التحقق

لا يعني فحص IPA أو نجاح تنزيله اعتماد سلامة التطبيق أو صلاحية توقيعه أو نجاح تثبيته على iPhone. خدمة التواصل غير مهيّأة، والوضع الافتراضي يحفظ مسودة محلية فقط؛ اختُبرت استجابات الإرسال عبر خدمة محاكاة معزولة. لا يوجد نشر عام إلى حساب GitHub ضمن هذا التسليم؛ مجلد `dist` جاهز للنشر والـworkflow مرفق. سيبقى `--require-files` غير ناجح حتى يتوفر ملف Android الأصلي.

## إعادة الاختبارات

```sh
python3 -m unittest discover -s tests -v
node --check assets/app.js
node --check assets/admin.js
node --check assets/legal.js
python3 scripts/build.py
python3 -m http.server 8765 --directory dist
# In another terminal, with Playwright and Chromium available:
node tests/browser.cjs
node tests/admin-browser.cjs
```

The current checks passed: 20 pipeline tests, 14 website browser suites, 6 local-editor suites, and 3 focused checks after final navigation fixes. The real IPA download matched the supplied original by size and SHA-256. Android remains Coming soon because its original APK is unavailable. Editor changes are browser-local until exported, rebuilt and deployed. The public PIN is a convenience gate, not server authentication. No public deployment, live contact provider, app-signing validation, or device-installation test is claimed.
