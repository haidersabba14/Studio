/* Haider Studio — static, dependency-free interactions. */
(() => {
  "use strict";
  const $ = (s, r = document) => r.querySelector(s),
    $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const scriptURL =
    document.currentScript?.src || new URL("assets/app.js", location.href).href;
  const ROOT = new URL("../", scriptURL),
    iconURL = new URL("assets/icons.svg", ROOT).href;
  const store = {
    get(k, f = null) {
      try {
        return localStorage.getItem(k) ?? f;
      } catch {
        return f;
      }
    },
    set(k, v) {
      try {
        localStorage.setItem(k, v);
        return true;
      } catch {
        return false;
      }
    },
    remove(k) {
      try {
        localStorage.removeItem(k);
      } catch {}
    },
  };
  const ar = {
    skip: "انتقل إلى المحتوى",
    home: "الرئيسية",
    apps: "التطبيقات",
    features: "المميزات",
    updates: "التحديثات",
    about: "من نحن",
    releaseNews: "مستجدات الإصدارات",
    markRead: "تحديد كمقروء",
    heroEyebrow: "صُنع بشغف. ليليق بك.",
    heroTitle1: "تجربة تستحق",
    heroTitle2: "التميّز.",
    heroDescription:
      "عالم Haider Studio بين يديك. اكتشف تطبيقاتنا لنظامَي iOS وAndroid، وتعرّف على كل إصدار في تجربة واحدة، بسيطة وأنيقة.",
    exploreApps: "استكشف التطبيقات",
    meetStudio: "تعرّف على الاستوديو",
    twoPlatforms: "نظامان. تجربة واحدة.",
    iosEdition: "إصدار iPhone",
    androidEdition: "إصدار Android",
    scrollExplore: "مرّر لتكتشف",
    promiseOne: "كل الإصدارات في مكان واحد",
    promiseTwo: "تفاصيل ملفات حقيقية",
    promiseThree: "تجربة بالعربية والإنجليزية",
    promiseFour: "بساطة في كل تفصيلة",
    libraryEyebrow: "مختارة لك",
    libraryTitle: 'تطبيقاتنا<span class="gold-text">.</span>',
    libraryDescription:
      "اختر نظامك، واكتشف إصدار Haider Studio المناسب لجهازك.",
    allPlatforms: "كل التطبيقات",
    noResults: "لم نجد تطبيقًا بهذا الاسم",
    trySearch: "جرّب كلمة أخرى أو اختر جميع التطبيقات.",
    resetSearch: "مسح البحث",
    libraryNote:
      "نعرض معلومات الملفات المتحقَّق منها فقط. يظهر رابط التحميل فور توفّر الملف الأصلي.",
    installationHelp: "مساعدة التثبيت ↗",
    detailsEyebrow: "التفاصيل تصنع الفارق",
    featuresTitle: "كل ما تحتاجه. بكل بساطة.",
    featureOneTitle: "اعثر على إصدارك",
    featureOneText:
      "بحث فوري وتصفية حسب النظام، للوصول إلى التطبيق المناسب دون تعقيد.",
    featureTwoTitle: "اعرف ما تُحمّله",
    featureTwoText:
      "الإصدار وحجم الملف وبصمة التحقق، مستخرجة من الملف الأصلي عندما يتوفر.",
    featureThreeTitle: "شاركها بطريقتك",
    featureThreeText:
      "انسخ رابط التطبيق أو شاركه مباشرة عبر واتساب وتليجرام بنقرة واحدة.",
    featureFourTitle: "تجربة تشبهك",
    featureFourText:
      "اختر لغتك وطريقة العرض ومستوى الحركة. تُحفظ تفضيلاتك على جهازك فقط.",
    updatesEyebrow: "ابقَ على اطّلاع",
    updatesTitle: 'آخر التحديثات<span class="gold-text">.</span>',
    updatesDescription:
      "معلومات أحدث الملفات المنشورة، مباشرة من مكتبة التطبيقات.",
    aboutEyebrow: "وراء التجربة",
    aboutTitle: "بصمة خاصة.<br>في كل تفصيلة.",
    aboutText:
      "Haider Studio مساحة تجمع تطبيقات الاستوديو وإصداراتها في وجهة واحدة. نؤمن بأن التجربة الجيدة تبدأ من الوضوح: معلومات تعرفها، وخطوات تفهمها، وتصميم يمنح كل تفصيلة حقّها.",
    contactUs: "تواصل معنا",
    faqEyebrow: "نجيب عن تساؤلاتك",
    faqTitle: 'قبل أن تبدأ<span class="gold-text">.</span>',
    faq1q: "كيف أثبّت ملف IPA على iPhone؟",
    faq1a:
      "تنزيل ملف IPA لا يثبّته تلقائيًا. تحتاج إلى وسيلة تثبيت موثوقة وتوقيع صالح يتوافق مع جهازك، مثل أدوات التحميل الجانبي التي تختارها. لا تشارك كلمة مرور Apple ID مع هذا الموقع. تحقّق من صلاحية التوقيع والتوافق قبل التثبيت.",
    faq2q: "كيف أثبّت تطبيق Android؟",
    faq2a:
      "حمّل ملف APK المتاح، ثم افتحه على جهاز Android. قد يطلب النظام السماح بالتثبيت من هذا المصدر؛ امنح الإذن عند ثقتك بالملف وألغِه بعد الانتهاء. ملف app-debug.apk إصدار تطوير وليس إصدار متجر؛ راجع تفاصيله قبل استخدامه.",
    faq3q: "لماذا لا يظهر زر تحميل فعّال؟",
    faq3a:
      "يُفعَّل التحميل فقط بعد إضافة الملف الأصلي والتحقّق منه أثناء تجهيز الموقع. إذا ظهر «قريبًا» أو «بانتظار الملف»، فالنسخة غير منشورة بعد. لا نستخدم روابط تنزيل تجريبية أو معلومات إصدار تقديرية.",
    faq4q: "هل يطلب الموقع صلاحيات أو يتتبّع التنزيلات؟",
    faq4a:
      "لا يطلب الموقع حسابًا أو إذنًا للإشعارات ولا يستخدم إحصاءات تنزيل. تحفظ اللغة والعرض والحركة ومسودة التواصل محليًا في متصفحك. لا تنتقل رسالتك إلى أي خدمة إلا عند تهيئة خدمة تواصل وإرسالها بواسطتك.",
    faq5q: "كيف أعرف بوجود إصدار جديد؟",
    faq5a:
      "عند فتح الموقع أو عودتك إليه، يتحقّق من قائمة الإصدارات. إذا تغيّر أحد الملفات منذ زيارتك السابقة، يظهر تنبيه داخل الموقع. لا توجد إشعارات خارج المتصفح أو في الخلفية.",
    contactEyebrow: "الحوار بداية كل شيء",
    contactTitle: 'لديك سؤال؟<br><span class="gold-text">نحن نسمعك.</span>',
    contactPrivacy:
      "بياناتك تخصّك. راجع سياسة الخصوصية لمعرفة طريقة التعامل معها.",
    privacy: "سياسة الخصوصية",
    terms: "الشروط والأحكام",
    yourName: "الاسم",
    yourEmail: "البريد الإلكتروني",
    yourMessage: "رسالتك",
    saveDraft: "حفظ المسودة على جهازي",
    copyMessage: "نسخ الرسالة",
    deleteDraft: "حذف المسودة",
    footerLine: "بشغف نصنع التجربة. وبالتفاصيل نترك الأثر.",
    reduceMotion: "تقليل الحركة",
    enableMotion: "تفعيل الحركة",
    searchPlaceholder: "ابحث عن تطبيق...",
    pending: "بانتظار الملف",
    comingSoon: "قريبًا",
    androidSoon:
      "نسخة Android قريبًا. سنعرض معلوماتها ورابطها عند نشر الملف الأصلي.",
    montage: "المونتاج",
    montageTitle: "المونتاج",
    montageDescription: "مساحة Haider Studio للمونتاج.",
    available: "ملف متاح",
    version: "الإصدار",
    size: "الحجم",
    unknown: "غير متوفر",
    downloadIPA: "تحميل IPA",
    downloadAPK: "تحميل APK",
    copyDownload: "نسخ رابط التنزيل",
    copyPage: "نسخ رابط التطبيق",
    details: "تفاصيل التطبيق",
    viewCompact: "عرض مدمج",
    viewCards: "عرض البطاقات",
    fileMissing: "الملف الأصلي غير متوفر بعد",
    iosDesc:
      "نسخة Haider Studio لأجهزة iPhone. تعرّف على معلومات الملف وخطوات تثبيت IPA قبل البدء.",
    androidDesc:
      "نسخة Haider Studio لنظام Android بصيغة APK. إصدار تطوير؛ راجع تفاصيل الملف قبل التثبيت.",
    androidLabel: "Android · إصدار تطوير",
    iosLabel: "iOS · ملف IPA",
    copied: "تم نسخ الرابط",
    copyFail: "تعذّر النسخ تلقائيًا. انسخ النص من الحقل الظاهر.",
    downloadError:
      "تعذّر الوصول إلى الملف. حاول لاحقًا أو راجع تفاصيل التطبيق.",
    checking: "جارٍ التحقق…",
    noPublished: "لم يُنشر إصدار قابل للتنزيل بعد",
    noPublishedText:
      "ستظهر هنا معلومات الإصدار عند إضافة الملف الأصلي والتحقّق منه.",
    newRelease: "تغيّرت ملفات منشورة منذ زيارتك السابقة.",
    currentRelease: "أحدث الملفات المتاحة في المكتبة.",
    recommendIOS: "يبدو أنك تستخدم iPhone أو iPad. نقترح إصدار iOS عند توفره.",
    recommendAndroid: "يبدو أنك تستخدم Android. نقترح إصدار APK عند توفره.",
    draftMode:
      "خدمة الإرسال غير متصلة حاليًا. يمكنك حفظ مسودة على جهازك أو نسخ رسالتك؛ لن تُرسل إلى أي جهة.",
    endpointMode:
      "أرسل رسالتك عبر خدمة التواصل المتصلة. تُنقل البيانات إلى مزوّد الخدمة عند الإرسال.",
    emailMode:
      "يفتح الإرسال تطبيق بريدك برسالة جاهزة، ويحتاج إلى تأكيد الإرسال منك هناك.",
    sendMessage: "إرسال الرسالة",
    openEmail: "فتح تطبيق البريد",
    draftSaved: "تم حفظ المسودة على هذا المتصفح فقط. لم تُرسل.",
    storageError:
      "المتصفح يمنع التخزين المحلي. يمكنك نسخ الرسالة بدلًا من ذلك.",
    draftDeleted: "حُذفت المسودة من هذا المتصفح.",
    messageCopied: "تم نسخ الرسالة. يمكنك إرسالها بالطريقة التي تختارها.",
    sent: "تم إرسال الرسالة بنجاح.",
    sending: "جارٍ الإرسال…",
    sendError: "لم يتم الإرسال. بقيت الرسالة في النموذج؛ حاول لاحقًا.",
    emailOpened: "فُتح رابط البريد. أكمل الإرسال في تطبيق بريدك.",
    build: "رقم البناء",
    minOS: "الحد الأدنى للنظام",
    packageId: "معرّف الحزمة",
    filename: "اسم الملف",
    fingerprint: "بصمة الملف SHA-256",
    installTitle: "قبل التثبيت",
    shareApp: "شارك التطبيق",
    backLibrary: "مكتبة التطبيقات",
    availableInfo:
      "الملف متاح؛ بيانات الحجم والإصدار مستخرجة أثناء تجهيز الموقع.",
    pendingInfo:
      "الملف الأصلي لم يُضف بعد. لا يوجد تنزيل متاح أو رقم إصدار مؤكّد.",
    readFaq: "اطّلع على تعليمات التثبيت",
    copyTextTitle: "انسخ النص التالي",
    close: "إغلاق",
    fileChecked:
      "تم فحص وجود الملف وبياناته؛ لا يعني ذلك اعتماد أمان التطبيق أو توقيعه.",
    noPermission: "لا يحتاج الموقع إلى صلاحيات إضافية.",
  };
  const en = {
    skip: "Skip to content",
    home: "Home",
    apps: "Apps",
    features: "Features",
    updates: "Updates",
    about: "About",
    releaseNews: "Release updates",
    markRead: "Mark as read",
    heroEyebrow: "Made with passion. Made for you.",
    heroTitle1: "An experience",
    heroTitle2: "that stands out.",
    heroDescription:
      "Your world of Haider Studio. Explore our iOS and Android apps and discover every release in one simple, thoughtfully designed experience.",
    exploreApps: "Explore the apps",
    meetStudio: "Meet the studio",
    twoPlatforms: "Two platforms. One experience.",
    iosEdition: "The iPhone edition",
    androidEdition: "The Android edition",
    scrollExplore: "Scroll to explore",
    promiseOne: "Every release, one destination",
    promiseTwo: "Real file information",
    promiseThree: "Arabic & English",
    promiseFour: "Simplicity in every detail",
    libraryEyebrow: "CURATED FOR YOU",
    libraryTitle: 'Our apps<span class="gold-text">.</span>',
    libraryDescription:
      "Choose your platform. Discover your edition of Haider Studio.",
    allPlatforms: "All apps",
    noResults: "No apps match your search",
    trySearch: "Try another term or select all platforms.",
    resetSearch: "Clear search",
    libraryNote:
      "Only verified file information is shown. Downloads become available when the original file is published.",
    installationHelp: "Installation help ↗",
    detailsEyebrow: "THE DETAILS MAKE THE DIFFERENCE",
    featuresTitle: "Everything you need. Simply.",
    featureOneTitle: "Find your edition",
    featureOneText:
      "Instant search and platform filters help you find the right app without the extra steps.",
    featureTwoTitle: "Know your download",
    featureTwoText:
      "Version, exact file size and verification hash, extracted from the original file when available.",
    featureThreeTitle: "Share it your way",
    featureThreeText:
      "Copy the app link or share it directly through WhatsApp and Telegram with a single click.",
    featureFourTitle: "Make it yours",
    featureFourText:
      "Choose your language, view and motion preference. Your settings stay on your device.",
    updatesEyebrow: "STAY IN THE KNOW",
    updatesTitle: 'Latest updates<span class="gold-text">.</span>',
    updatesDescription:
      "The latest published file information, straight from the app library.",
    aboutEyebrow: "BEHIND THE EXPERIENCE",
    aboutTitle: "A distinct signature.<br>In every detail.",
    aboutText:
      "Haider Studio brings the studio’s apps and releases together in one destination. We believe a good experience begins with clarity: information you understand, steps you can follow, and a design that gives every detail its due.",
    contactUs: "Get in touch",
    faqEyebrow: "YOUR QUESTIONS, ANSWERED",
    faqTitle: 'Before you begin<span class="gold-text">.</span>',
    faq1q: "How do I install an IPA on iPhone?",
    faq1a:
      "Downloading an IPA does not automatically install it. You need a trusted installation method and a valid signature compatible with your device, such as your chosen sideloading tool. Never share your Apple ID password with this site. Check signing and compatibility before installing.",
    faq2q: "How do I install the Android app?",
    faq2a:
      "Download the available APK and open it on your Android device. Android may ask you to allow installation from this source; grant access only if you trust the file, and revoke it afterwards. app-debug.apk is a development build rather than a store release. Review its details before use.",
    faq3q: "Why is the download button unavailable?",
    faq3a:
      "Downloads are enabled only after the original package is added and checked during the site build. “Coming soon” or “Awaiting file” means the build has not been published. We do not use sample download links or estimated version information.",
    faq4q: "Does the site request permissions or track downloads?",
    faq4a:
      "No account or notification permission is required, and no download analytics are used. Language, display, motion preferences and saved contact drafts stay in your browser. Messages leave your device only when a contact service is configured and you submit them.",
    faq5q: "How will I know about a new release?",
    faq5a:
      "The site checks its release list when you open it or return to it. If a published file has changed since your previous visit, an in-site notice appears. There are no background or push notifications.",
    contactEyebrow: "EVERYTHING STARTS WITH A CONVERSATION",
    contactTitle:
      'Have a question?<br><span class="gold-text">We’re listening.</span>',
    contactPrivacy:
      "Your data belongs to you. Read our privacy policy to understand how it is handled.",
    privacy: "Privacy policy",
    terms: "Terms & conditions",
    yourName: "Your name",
    yourEmail: "Email address",
    yourMessage: "Your message",
    saveDraft: "Save a draft on my device",
    copyMessage: "Copy message",
    deleteDraft: "Delete draft",
    footerLine: "Made with passion. Remembered for the details.",
    reduceMotion: "Reduce motion",
    enableMotion: "Enable motion",
    searchPlaceholder: "Search for an app...",
    pending: "Awaiting file",
    comingSoon: "Coming soon",
    androidSoon:
      "The Android edition is coming soon. Its details and download will appear when the original package is published.",
    montage: "Video editing",
    montageTitle: "Video editing",
    montageDescription: "The Haider Studio editing collection.",
    available: "File available",
    version: "Version",
    size: "Size",
    unknown: "Not available",
    downloadIPA: "Download IPA",
    downloadAPK: "Download APK",
    copyDownload: "Copy download link",
    copyPage: "Copy app link",
    details: "App details",
    viewCompact: "Compact view",
    viewCards: "Card view",
    fileMissing: "The original file is not available yet",
    iosDesc:
      "The iPhone edition of Haider Studio. Review file details and IPA installation steps before getting started.",
    androidDesc:
      "Haider Studio for Android in APK format. A development build; review file details before installation.",
    androidLabel: "Android · Development build",
    iosLabel: "iOS · IPA package",
    copied: "Link copied",
    copyFail:
      "Automatic copying is unavailable. Copy the text from the field shown.",
    downloadError:
      "The file could not be reached. Try later or review the app details.",
    checking: "Checking file…",
    noPublished: "No downloadable release published yet",
    noPublishedText:
      "Release information will appear here once the original file has been added and checked.",
    newRelease: "Published files have changed since your previous visit.",
    currentRelease: "The latest available files in the library.",
    recommendIOS:
      "It looks like you use an iPhone or iPad. We recommend the iOS edition when available.",
    recommendAndroid:
      "It looks like you use Android. We recommend the APK edition when available.",
    draftMode:
      "Sending is not connected yet. You can save a draft on your device or copy your message; nothing will be sent.",
    endpointMode:
      "Send your message using the connected contact service. Your data is transferred to that provider when submitted.",
    emailMode:
      "Sending opens a prepared message in your email app. You must confirm sending there.",
    sendMessage: "Send message",
    openEmail: "Open email app",
    draftSaved: "Draft saved in this browser only. Nothing was sent.",
    storageError:
      "This browser blocks local storage. You can copy your message instead.",
    draftDeleted: "Draft deleted from this browser.",
    messageCopied: "Message copied. Send it using the method you prefer.",
    sent: "Message sent successfully.",
    sending: "Sending…",
    sendError:
      "Your message was not sent. It remains in the form; please try again later.",
    emailOpened: "Email link opened. Complete sending in your email app.",
    build: "Build number",
    minOS: "Minimum system",
    packageId: "Package ID",
    filename: "File name",
    fingerprint: "SHA-256 file fingerprint",
    installTitle: "Before installing",
    shareApp: "Share this app",
    backLibrary: "App library",
    availableInfo:
      "The file is available. Size and version information were extracted during the site build.",
    pendingInfo:
      "The original file has not been added yet. No download or verified version is available.",
    readFaq: "Read installation instructions",
    copyTextTitle: "Copy the following text",
    close: "Close",
    fileChecked:
      "File presence and metadata were checked. This does not certify app security or signing.",
    noPermission: "No additional permissions needed.",
  };
  let lang = store.get("hs-language", "ar") === "en" ? "en" : "ar",
    filter = ["all", "ios", "android"].includes(store.get("hs-filter"))
      ? store.get("hs-filter")
      : "all",
    query = "",
    compact = store.get("hs-view") === "compact",
    motion =
      store.get("hs-motion") ||
      (matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "reduced"
        : "full");
  let releases = Array.isArray(window.HAIDER_RELEASES)
    ? window.HAIDER_RELEASES
    : [];
  let apps = Array.isArray(window.HAIDER_APPS) ? window.HAIDER_APPS : [],
    build = window.HAIDER_BUILD || {},
    config = window.HAIDER_CONFIG || {},
    toastTimer,
    notificationNew = false;
  function isPlainRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }
  function exactKeys(value, keys) {
    return (
      isPlainRecord(value) &&
      Object.keys(value).length === keys.length &&
      keys.every((key) => Object.hasOwn(value, key))
    );
  }
  function contentString(value, limit) {
    return (
      typeof value === "string" &&
      value.length <= limit &&
      !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value)
    );
  }
  function validContent(value) {
    if (
      !exactKeys(value, ["schemaVersion", "hero", "montage", "apps"]) ||
      value.schemaVersion !== 1 ||
      !exactKeys(value.hero, ["ar", "en"]) ||
      !exactKeys(value.montage, ["ar", "en"]) ||
      !exactKeys(
        value.apps,
        apps.map((app) => app.id),
      )
    )
      return false;
    for (const language of ["ar", "en"]) {
      const hero = value.hero[language],
        montage = value.montage[language];
      if (
        !exactKeys(hero, ["title1", "title2", "description"]) ||
        !contentString(hero.title1, 120) ||
        !contentString(hero.title2, 120) ||
        !contentString(hero.description, 2000) ||
        !exactKeys(montage, ["title", "description"]) ||
        !contentString(montage.title, 120) ||
        !contentString(montage.description, 2000)
      )
        return false;
    }
    const ids = new Set(apps.map((app) => app.id));
    for (const [id, app] of Object.entries(value.apps)) {
      if (
        !ids.has(id) ||
        !exactKeys(app, ["name", "description"]) ||
        !contentString(app.name, 120) ||
        !exactKeys(app.description, ["ar", "en"]) ||
        !contentString(app.description.ar, 2000) ||
        !contentString(app.description.en, 2000)
      )
        return false;
    }
    return true;
  }
  const cloneContent = (value) => JSON.parse(JSON.stringify(value));
  const factoryContent = {
    schemaVersion: 1,
    hero: {
      ar: {
        title1: ar.heroTitle1,
        title2: ar.heroTitle2,
        description: ar.heroDescription,
      },
      en: {
        title1: en.heroTitle1,
        title2: en.heroTitle2,
        description: en.heroDescription,
      },
    },
    montage: {
      ar: { title: ar.montageTitle, description: ar.montageDescription },
      en: { title: en.montageTitle, description: en.montageDescription },
    },
    apps: Object.fromEntries(
      apps.map((app) => [
        app.id,
        {
          name: app.name || "Haider Studio",
          description: {
            ar: app.description?.ar || "",
            en: app.description?.en || "",
          },
        },
      ]),
    ),
  };
  const publishedContent = {
    ...factoryContent,
    ...(window.HAIDER_CONTENT || {}),
    apps: { ...factoryContent.apps, ...(window.HAIDER_CONTENT?.apps || {}) },
  };
  const defaultContent = validContent(publishedContent)
    ? publishedContent
    : factoryContent;
  let activeContent = cloneContent(defaultContent);
  try {
    const local = JSON.parse(store.get("hs-studio-content", "null"));
    if (validContent(local)) activeContent = local;
  } catch {}
  window.HAIDER_DEFAULT_CONTENT = cloneContent(defaultContent);
  window.HAIDER_CONTENT = cloneContent(activeContent);
  function applyContentText() {
    const hero = activeContent.hero[lang],
      montage = activeContent.montage[lang];
    const values = {
      heroTitle1: hero.title1,
      heroTitle2: hero.title2,
      heroDescription: hero.description,
      montageTitle: montage.title,
      montageDescription: montage.description,
    };
    for (const [key, text] of Object.entries(values))
      $$(`[data-i18n="${key}"]`).forEach((node) => (node.textContent = text));
  }
  window.addEventListener("haider:content-change", (event) => {
    if (!validContent(event.detail)) return;
    activeContent = cloneContent(event.detail);
    window.HAIDER_CONTENT = cloneContent(activeContent);
    setLanguage(lang);
  });
  const t = (k) => (lang === "ar" ? ar : en)[k] || ar[k] || k;
  const esc = (v) =>
    String(v ?? "").replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    );
  const icon = (id) =>
    `<svg aria-hidden="true"><use href="${iconURL}#${id}"/></svg>`;
  const appName = (app) =>
    activeContent.apps[app.id]?.name ?? app.name ?? "Haider Studio";
  const appDescription = (app) =>
    activeContent.apps[app.id]?.description?.[lang] ??
    app.description?.[lang] ??
    t(app.platform === "ios" ? "iosDesc" : "androidDesc");
  const appEdition = (app) =>
    app.platform === "ios"
      ? t("iosLabel")
      : app.available && app.filename === "app-debug.apk"
        ? t("androidLabel")
        : "Android · APK";
  const detailURL = (id) => new URL(`apps/${id}.html`, ROOT).href;
  function safeDownload(app) {
    if (!app?.available || !app.url) return null;
    try {
      const u = new URL(app.url, ROOT);
      if (
        u.protocol === "https:" ||
        (u.origin === ROOT.origin && u.protocol === "http:")
      )
        return u.href;
    } catch {}
    return null;
  }
  function fileSize(size) {
    if (!Number.isFinite(size)) return t("unknown");
    return size < 1048576
      ? `${(size / 1024).toFixed(1)} KB`
      : `${(size / 1048576).toFixed(2)} MB`;
  }
  function toast(msg) {
    const node = $("#toast");
    if (!node) return;
    node.textContent = msg;
    node.classList.add("visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => node.classList.remove("visible"), 5000);
  }
  async function copy(text, success = t("copied")) {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        const area = document.createElement("textarea");
        area.value = text;
        area.style.cssText = "position:fixed;top:0;left:-9999px";
        document.body.append(area);
        area.select();
        const ok = document.execCommand("copy");
        area.remove();
        if (!ok) throw Error("copy");
      }
      toast(success);
      return true;
    } catch {
      showCopyDialog(text);
      return false;
    }
  }
  function showCopyDialog(text) {
    let dialog = $("#copy-dialog");
    if (!dialog) {
      dialog = document.createElement("dialog");
      dialog.id = "copy-dialog";
      dialog.style.cssText =
        "background:#171b12;color:#ead39a;border:1px solid #ad9454;border-radius:10px;width:min(480px,90%);padding:24px";
      document.body.append(dialog);
    }
    dialog.innerHTML = `<p>${esc(t("copyFail"))}</p><label>${esc(t("copyTextTitle"))}<textarea readonly style="width:100%;height:110px;margin:15px 0;background:#0a0d07;color:#ddd;border:1px solid #78663d;padding:10px" dir="auto"></textarea></label><button class="button button-outline">${esc(t("close"))}</button>`;
    $("textarea", dialog).value = text;
    $("button", dialog).onclick = () => dialog.close();
    dialog.showModal();
    $("textarea", dialog).focus();
    $("textarea", dialog).select();
  }
  function shareURL(app, service) {
    const link = detailURL(app.id),
      text = `${appName(app)} · ${app.platform === "ios" ? "iOS" : "Android"}`;
    return service === "wa"
      ? `https://wa.me/?text=${encodeURIComponent(text + " " + link)}`
      : `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(text)}`;
  }
  function card(app) {
    const url = safeDownload(app),
      platform = app.platform === "ios" ? "iOS" : "Android";
    return `<article class="app-card ${app.platform}-card" data-id="${esc(app.id)}"><div class="card-art" aria-hidden="true"><span class="card-platform">${icon(app.platform === "ios" ? "apple" : "android")}${platform}</span><div class="app-logo"><img src="${new URL("assets/haider-logo-gold.png", ROOT).href}" alt="" width="1280" height="1280" loading="lazy" /></div></div><div class="card-body"><div class="card-title-row"><div><h3><a href="${detailURL(app.id)}" dir="auto">${esc(appName(app))}</a></h3><span class="card-edition">${esc(appEdition(app))}</span></div><span class="status-chip"><i></i>${esc(t(url ? "available" : app.platform === "android" ? "comingSoon" : "pending"))}</span></div><p class="card-description">${esc(appDescription(app))}</p><div class="card-metadata"><span>${esc(t("version"))}<strong dir="auto">${esc(app.version || "—")}</strong></span><span>${esc(t("size"))}<strong dir="auto">${esc(app.size === null ? "—" : fileSize(app.size))}</strong></span><span><strong dir="ltr">${app.platform === "ios" ? "IPA" : "APK"}</strong></span></div><div class="card-buttons"><button class="button button-gold download-button" data-download="${app.id}" ${!url ? "disabled" : ""} ${!url ? `title="${esc(t("fileMissing"))}"` : ""}>${icon("download")}<span>${esc(t(url ? (app.platform === "ios" ? "downloadIPA" : "downloadAPK") : app.platform === "android" ? "comingSoon" : "pending"))}</span></button><button class="icon-button" data-copy-download="${app.id}" aria-label="${esc(t("copyDownload"))}" title="${esc(t("copyDownload"))}" ${!url ? "disabled" : ""}>${icon("copy")}</button></div><div class="card-footer"><a class="card-details" href="${detailURL(app.id)}">${esc(t("details"))}${icon("arrow-diagonal")}</a><div class="card-share"><button data-copy-page="${app.id}" aria-label="${esc(t("copyPage"))}" title="${esc(t("copyPage"))}">${icon("share")}</button><a href="${shareURL(app, "wa")}" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp">WhatsApp</a><a href="${shareURL(app, "tg")}" target="_blank" rel="noopener noreferrer" aria-label="Telegram">Telegram</a></div></div></div></article>`;
  }
  function renderApps() {
    const grid = $("#app-grid");
    if (!grid) return;
    const clean = (s) => s.toLocaleLowerCase().normalize("NFKC");
    const results = apps.filter(
      (a) =>
        (filter === "all" || a.platform === filter) &&
        clean(
          `${appName(a)} ${appDescription(a)} ${a.filename} ${a.platform} ${a.platform === "ios" ? "iphone ipad ايفون آيفون" : "أندرويد اندرويد"} هايدر حيدر استوديو`,
        ).includes(clean(query.trim())),
    );
    grid.innerHTML = results.map(card).join("");
    grid.classList.toggle("compact", compact);
    $("#empty-state").hidden = results.length > 0;
    $$("[data-filter]").forEach((b) => {
      const active = b.dataset.filter === filter;
      b.classList.toggle("active", active);
      b.setAttribute("aria-pressed", String(active));
    });
    const v = $("#view-toggle");
    if (v) {
      v.setAttribute("aria-label", t(compact ? "viewCards" : "viewCompact"));
      v.setAttribute("aria-pressed", String(compact));
    }
  }
  function renderUpdates() {
    const history = $("#release-history");
    if (history) {
      history.innerHTML = releases.length
        ? `<details class="release-history"><summary>${lang === "ar" ? "سجل الإصدارات الموثّقة" : "Verified release history"} <span>+</span></summary><p>${lang === "ar" ? "سجل الملفات التي تم تجهيزها والتحقّق منها. لا يوفّر روابط تنزيل للإصدارات القديمة." : "A record of files checked during release builds. Historical downloads are not provided."}</p>${[
            ...releases,
          ]
            .reverse()
            .map(
              (r) =>
                `<div class="history-row"><span dir="ltr">${esc(r.platform === "ios" ? "iOS" : "Android")} · ${esc(r.version || t("unknown"))} · ${esc(fileSize(r.size))}</span><code dir="ltr">SHA-256: ${esc(r.sha256)}</code></div>`,
            )
            .join("")}</details>`
        : "";
    }
    const available = apps.filter((a) => safeDownload(a));
    const list = $("#updates-list");
    if (list)
      list.innerHTML = available.length
        ? available
            .map(
              (a) =>
                `<article class="update-row"><span class="platform-box">${icon(a.platform === "ios" ? "apple" : "android")}</span><div><h3 dir="auto">${esc(appName(a))} · ${a.platform === "ios" ? "iOS" : "Android"}</h3><p>${esc(a.filename)} · ${fileSize(a.size)}</p></div><span class="update-version" dir="auto">${esc(a.version || t("unknown"))}</span><a class="text-link" href="${detailURL(a.id)}">${esc(t("details"))}${icon("arrow-diagonal")}</a></article>`,
            )
            .join("")
        : `<div class="updates-empty"><span class="feature-icon">${icon("layers")}</span><div><h3>${esc(t("noPublished"))}</h3><p>${esc(t("noPublishedText"))}</p></div></div>`;
    const n = $("#notification-content");
    if (n)
      n.innerHTML = available.length
        ? `<p>${esc(t(notificationNew ? "newRelease" : "currentRelease"))}</p>` +
          available
            .map(
              (a) =>
                `<p><a href="${detailURL(a.id)}">${esc(appName(a))} · ${a.platform === "ios" ? "iOS" : "Android"} · ${esc(a.version || t("unknown"))}</a></p>`,
            )
            .join("")
        : `<p>${esc(t("noPublished"))}</p><p>${esc(t("noPublishedText"))}</p>`;
    $$(".notification-dot").forEach((n) => (n.hidden = !notificationNew));
  }
  function renderDevice() {
    const n = $("#device-hint");
    if (!n) return;
    const ua = navigator.userAgent;
    const ios =
      /iPhone|iPad|iPod/i.test(ua) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    const android = /Android/i.test(ua);
    n.hidden = !ios && !android;
    n.innerHTML =
      ios || android
        ? `${icon(ios ? "apple" : "android")} ${esc(t(ios ? "recommendIOS" : "recommendAndroid"))}`
        : "";
  }
  function renderDetails() {
    const target = $("#app-detail");
    if (!target) return;
    const app = apps.find((a) => a.id === document.body.dataset.app);
    if (!app) {
      target.innerHTML = `<h1>${esc(t("noResults"))}</h1><a class="button button-gold" href="${ROOT.href}">${esc(t("home"))}</a>`;
      return;
    }
    const url = safeDownload(app),
      platform = app.platform === "ios" ? "iOS" : "Android";
    document.title = `${appName(app)} · ${platform} — ${t("details")}`;
    const field = (label, value, cls = "") =>
      `<div class="${cls}"><small>${esc(t(label))}</small><strong dir="auto">${esc(value || t("unknown"))}</strong></div>`;
    target.innerHTML = `<div class="breadcrumb"><a href="${new URL("index.html#apps", ROOT)}">${esc(t("backLibrary"))}</a><span>/</span><span>${esc(appName(app))} · ${platform}</span></div><div class="detail-layout"><div class="detail-art ${app.platform}-card"><div class="card-art" aria-hidden="true"><div class="app-logo"><img src="${new URL("assets/haider-logo-gold.png", ROOT).href}" alt="" width="1280" height="1280" loading="lazy" /></div></div><div class="detail-instructions"><h2>${esc(t("installTitle"))}</h2><p>${esc(t(app.platform === "ios" ? "faq1a" : "faq2a"))}</p><a class="text-link" style="margin-top:15px" href="${new URL("index.html#faq", ROOT)}">${esc(t("readFaq"))} ↗</a></div></div><div class="detail-content"><div class="eyebrow">✦ ${esc(appEdition(app))}</div><h1 dir="auto">${esc(appName(app))}</h1><span class="status-chip" style="display:inline-flex">${esc(t(url ? "available" : app.platform === "android" ? "comingSoon" : "pending"))}</span><p>${esc(appDescription(app))}</p><p>${esc(t(url ? "availableInfo" : app.platform === "android" ? "androidSoon" : "pendingInfo"))}</p><div class="detail-metadata">${field("version", app.version)}${field("size", app.size === null ? null : fileSize(app.size))}${field("build", app.build)}${field("minOS", app.minOS)}${field("filename", app.filename)}${field("packageId", app.packageId)}${field("fingerprint", app.sha256, "detail-sha")}</div><div class="detail-actions"><button class="button button-gold download-button" data-download="${app.id}" ${!url ? "disabled" : ""}>${icon("download")}<span>${esc(t(url ? (app.platform === "ios" ? "downloadIPA" : "downloadAPK") : app.platform === "android" ? "comingSoon" : "pending"))}</span></button><button class="button button-outline" data-copy-download="${app.id}" ${!url ? "disabled" : ""} aria-label="${esc(t("copyDownload"))}">${icon("copy")}</button></div><div class="detail-share"><span>${esc(t("shareApp"))}</span><button data-copy-page="${app.id}">${esc(t("copyPage"))}</button><a href="${shareURL(app, "wa")}" target="_blank" rel="noopener noreferrer">WhatsApp</a><a href="${shareURL(app, "tg")}" target="_blank" rel="noopener noreferrer">Telegram</a></div>${url ? `<p>${esc(t("fileChecked"))}</p>` : ""}</div></div>`;
  }
  const endpoint = (() => {
    try {
      const u = new URL(config.contactEndpoint);
      return u.protocol === "https:" ? u.href : null;
    } catch {
      return null;
    }
  })();
  const email =
    typeof config.contactEmail === "string" &&
    /^[^\s@?&#]+@[^\s@?&#]+\.[^\s@?&#]+$/.test(config.contactEmail)
      ? config.contactEmail
      : null;
  function contactMode() {
    const status = $("#contact-status"),
      submit = $("#contact-submit");
    if (status) {
      status.textContent = t(
        endpoint ? "endpointMode" : email ? "emailMode" : "draftMode",
      );
      if (endpoint) {
        const link = document.createElement("a");
        link.href = endpoint;
        link.textContent = " " + new URL(endpoint).hostname;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        link.style.color = "var(--gold)";
        status.append(link);
      } else if (email) {
        const span = document.createElement("span");
        span.textContent = " " + email;
        span.dir = "ltr";
        status.append(span);
      }
    }
    if (submit) {
      const span = $("span", submit);
      span.textContent = t(
        endpoint ? "sendMessage" : email ? "openEmail" : "saveDraft",
      );
    }
  }
  function setLanguage(next) {
    lang = next;
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    store.set("hs-language", lang);
    $$("[data-i18n]").forEach((n) => (n.innerHTML = t(n.dataset.i18n)));
    $$("[data-root-link]").forEach(
      (n) => (n.href = new URL(n.dataset.rootLink, ROOT)),
    );
    const l = $("#language-toggle");
    if (l) {
      l.innerHTML = `${lang === "ar" ? "EN" : "عربي"} ${icon("globe")}`;
      l.setAttribute(
        "aria-label",
        lang === "ar" ? "Switch to English" : "التبديل إلى العربية",
      );
    }
    const input = $("#app-search");
    if (input) {
      input.placeholder = t("searchPlaceholder");
      input.setAttribute("aria-label", t("searchPlaceholder"));
    }
    if ($("#contact-name")) {
      $("#contact-name").placeholder =
        lang === "ar" ? "اسمك الكريم" : "Your name";
      $("#contact-message").placeholder =
        lang === "ar" ? "كيف يمكننا مساعدتك؟" : "How can we help?";
    }
    const motionButton = $("#motion-toggle");
    if (motionButton) {
      motionButton.textContent = t(
        motion === "reduced" ? "enableMotion" : "reduceMotion",
      );
      motionButton.setAttribute("aria-pressed", String(motion === "reduced"));
    }
    $("#back-top")?.setAttribute(
      "aria-label",
      lang === "ar" ? "العودة لأعلى" : "Back to top",
    );
    $("#menu-toggle")?.setAttribute(
      "aria-label",
      lang === "ar" ? "فتح القائمة" : "Toggle navigation",
    );
    $("#notifications-toggle")?.setAttribute("aria-label", t("releaseNews"));
    $("#navigation")?.setAttribute(
      "aria-label",
      lang === "ar" ? "التنقل الرئيسي" : "Main navigation",
    );
    $(".filter-group")?.setAttribute(
      "aria-label",
      lang === "ar" ? "تصفية حسب النظام" : "Filter by platform",
    );
    if (document.body.dataset.page === "home") {
      document.title =
        lang === "ar"
          ? "HAIDER STUDIO — تجربة تستحق التميّز"
          : "HAIDER STUDIO — Designed to stand out";
      $("meta[name=description]")?.setAttribute(
        "content",
        lang === "ar"
          ? "مكتبة تطبيقات Haider Studio لنظامَي iOS وAndroid. الإصدارات وتفاصيل الملفات وإرشادات التثبيت في مكان واحد."
          : "Haider Studio apps for iOS and Android. Explore release information, file details and installation guidance.",
      );
    }
    applyContentText();
    renderApps();
    renderUpdates();
    renderDevice();
    renderDetails();
    contactMode();
  }
  function applyMotion() {
    document.documentElement.classList.toggle(
      "allow-motion",
      motion === "full",
    );
    document.documentElement.classList.toggle(
      "reduce-motion",
      motion === "reduced",
    );
  }
  async function download(app, button) {
    const url = safeDownload(app);
    if (!url) return;
    const label = $("span", button);
    const old = label?.textContent;
    if (label) label.textContent = t("checking");
    button.disabled = true;
    try {
      const u = new URL(url);
      if (u.origin === location.origin) {
        let r = await fetch(url, {
          method: "HEAD",
          cache: "no-store",
          signal: AbortSignal.timeout(12000),
        });
        if (!r.ok || /text\/html/i.test(r.headers.get("content-type") || ""))
          throw Error("missing");
        const length = Number(r.headers.get("content-length"));
        if (length && app.size && length !== app.size) throw Error("changed");
      }
      const a = document.createElement("a");
      a.href = url;
      a.download = app.filename;
      if (u.origin !== location.origin) {
        a.target = "_blank";
        a.rel = "noopener noreferrer";
      }
      document.body.append(a);
      a.click();
      a.remove();
    } catch {
      toast(t("downloadError"));
    } finally {
      button.disabled = false;
      if (label) label.textContent = old;
    }
  }
  let lastCheck = 0;
  async function checkUpdates() {
    if (Date.now() - lastCheck < 30000) return;
    lastCheck = Date.now();
    try {
      const r = await fetch(new URL("assets/build-info.json", ROOT), {
        cache: "no-store",
      });
      if (!r.ok) return;
      const next = await r.json();
      if (!next.fingerprint) return;
      const previous = store.get("hs-release-seen");
      if (
        previous &&
        previous !== next.fingerprint &&
        apps.some((a) => safeDownload(a))
      ) {
        notificationNew = true;
        renderUpdates();
        toast(t("newRelease"));
      }
      if (!previous) store.set("hs-release-seen", next.fingerprint);
      if (next.fingerprint !== build.fingerprint) {
        const dataResponse = await fetch(new URL("assets/apps.json", ROOT), {
          cache: "no-store",
        });
        if (dataResponse.ok) {
          const data = await dataResponse.json();
          if (
            Array.isArray(data) &&
            data.every(
              (a) =>
                /^[a-z0-9][a-z0-9-]*$/.test(a.id) &&
                ["ios", "android"].includes(a.platform),
            )
          ) {
            apps = data;
            build = next;
            try {
              const hr = await fetch(new URL("assets/releases.json", ROOT), {
                cache: "no-store",
              });
              if (hr.ok) {
                const hd = await hr.json();
                if (Array.isArray(hd)) releases = hd;
              }
            } catch {}
            if (
              previous &&
              previous !== next.fingerprint &&
              apps.some((a) => safeDownload(a)) &&
              !notificationNew
            ) {
              notificationNew = true;
              toast(t("newRelease"));
            }
            renderApps();
            renderDetails();
            renderUpdates();
          }
        }
      }
    } catch {
      /* Offline visits retain the last available release list. */
    }
  }
  function bind() {
    document.addEventListener("click", (e) => {
      const b = e.target.closest(
        "[data-download],[data-copy-download],[data-copy-page]",
      );
      if (!b || b.disabled) return;
      const id =
        b.dataset.download || b.dataset.copyDownload || b.dataset.copyPage;
      const app = apps.find((a) => a.id === id);
      if (!app) return;
      if (b.hasAttribute("data-download")) download(app, b);
      else if (b.hasAttribute("data-copy-download")) {
        const u = safeDownload(app);
        if (u) copy(u);
      } else copy(detailURL(id));
    });
    $("#language-toggle")?.addEventListener("click", () =>
      setLanguage(lang === "ar" ? "en" : "ar"),
    );
    $$("[data-filter]").forEach((b) =>
      b.addEventListener("click", () => {
        filter = b.dataset.filter;
        store.set("hs-filter", filter);
        renderApps();
      }),
    );
    $("#app-search")?.addEventListener("input", (e) => {
      query = e.target.value;
      renderApps();
    });
    $("#reset-search")?.addEventListener("click", () => {
      query = "";
      filter = "all";
      store.set("hs-filter", filter);
      $("#app-search").value = "";
      renderApps();
      $("#app-search").focus();
    });
    $("#view-toggle")?.addEventListener("click", () => {
      compact = !compact;
      store.set("hs-view", compact ? "compact" : "cards");
      renderApps();
    });
    $("#motion-toggle")?.addEventListener("click", () => {
      motion = motion === "reduced" ? "full" : "reduced";
      store.set("hs-motion", motion);
      applyMotion();
      setLanguage(lang);
    });
    $("#menu-toggle")?.addEventListener("click", () => {
      const open = $("#navigation").classList.toggle("open");
      $("#menu-toggle").setAttribute("aria-expanded", String(open));
    });
    $$("#navigation a").forEach((a) =>
      a.addEventListener("click", () => {
        $("#navigation").classList.remove("open");
        $("#menu-toggle")?.setAttribute("aria-expanded", "false");
      }),
    );
    $("#notifications-toggle")?.addEventListener("click", () => {
      const box = $("#notifications");
      box.hidden = !box.hidden;
      $("#notifications-toggle").setAttribute(
        "aria-expanded",
        String(!box.hidden),
      );
    });
    $("#mark-read")?.addEventListener("click", () => {
      store.set("hs-release-seen", build.fingerprint || "");
      notificationNew = false;
      renderUpdates();
      $("#notifications").hidden = true;
      $("#notifications-toggle").setAttribute("aria-expanded", "false");
    });
    document.addEventListener("click", (e) => {
      if (
        !e.target.closest("#notifications,#notifications-toggle") &&
        $("#notifications")
      ) {
        $("#notifications").hidden = true;
        $("#notifications-toggle").setAttribute("aria-expanded", "false");
      }
    });
    document.addEventListener("keydown", (e) => {
      if (
        e.key === "/" &&
        !/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName) &&
        $("#app-search")
      ) {
        e.preventDefault();
        $("#app-search").focus();
      }
      if (e.key === "Escape") {
        $("#navigation")?.classList.remove("open");
        $("#menu-toggle")?.setAttribute("aria-expanded", "false");
        if ($("#notifications")) {
          $("#notifications").hidden = true;
          $("#notifications-toggle").setAttribute("aria-expanded", "false");
        }
      }
    });
    document.addEventListener("pointermove", (e) => {
      const card = e.target.closest(".app-card");
      if (!card || motion === "reduced" || e.pointerType === "touch") return;
      const r = card.getBoundingClientRect();
      card.style.setProperty("--mouse-x", `${e.clientX - r.left}px`);
      card.style.setProperty("--mouse-y", `${e.clientY - r.top}px`);
    });
    window.addEventListener(
      "scroll",
      () => $("#back-top")?.classList.toggle("visible", scrollY > 550),
      { passive: true },
    );
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) checkUpdates();
    });
    if ("IntersectionObserver" in window) {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              $$("#navigation a").forEach((a) =>
                a.classList.toggle(
                  "active",
                  a.hash === `#${entry.target.id}` ||
                    (entry.target.id === "apps" && a.hash === "#montage"),
                ),
              );
            }
          });
        },
        { rootMargin: "-20% 0px -60% 0px" },
      );
      $$("main>section[id]").forEach((s) => observer.observe(s));
    }
  }
  function bindContact() {
    const form = $("#contact-form");
    if (!form) return;
    try {
      const saved = JSON.parse(store.get("hs-contact-draft", "null"));
      if (saved) {
        for (const key of ["name", "email", "message"])
          if (typeof saved[key] === "string")
            form.elements[key].value = saved[key];
      }
    } catch {}
    const data = () => Object.fromEntries(new FormData(form).entries());
    const message = () => {
      const d = data();
      return `${d.name}\n${d.email}\n\n${d.message}`;
    };
    $("#copy-message").addEventListener("click", () => {
      if (form.reportValidity()) copy(message(), t("messageCopied"));
    });
    $("#delete-draft").addEventListener("click", () => {
      store.remove("hs-contact-draft");
      form.reset();
      $("#form-feedback").textContent = t("draftDeleted");
    });
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!form.reportValidity()) return;
      const d = data(),
        feedback = $("#form-feedback"),
        submit = $("#contact-submit");
      if (endpoint) {
        submit.disabled = true;
        feedback.textContent = t("sending");
        try {
          const r = await fetch(endpoint, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
            },
            body: JSON.stringify(d),
            signal: AbortSignal.timeout(20000),
          });
          if (!r.ok) throw Error("send");
          feedback.textContent = t("sent");
          store.remove("hs-contact-draft");
          form.reset();
        } catch {
          feedback.textContent = t("sendError");
        } finally {
          submit.disabled = false;
        }
      } else if (email) {
        location.href = `mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent("Haider Studio — " + d.name)}&body=${encodeURIComponent(message())}`;
        feedback.textContent = t("emailOpened");
      } else
        feedback.textContent = t(
          store.set("hs-contact-draft", JSON.stringify(d))
            ? "draftSaved"
            : "storageError",
        );
    });
  }
  applyMotion();
  bind();
  setLanguage(lang);
  bindContact();
  if ($("#year")) $("#year").textContent = new Date().getFullYear();
  const p = $("#particles");
  if (p) {
    for (let i = 0; i < 27; i++) {
      const star = document.createElement("i");
      star.className = "particle";
      star.style.cssText = `--x:${(i * 37.1) % 100}%;--y:${(i * 27.3) % 100}%;--duration:${4 + (i % 7)}s;animation-delay:-${i % 6}s`;
      p.append(star);
    }
  }
  const seen = store.get("hs-release-seen");
  if (
    seen &&
    build.fingerprint &&
    seen !== build.fingerprint &&
    apps.some((a) => safeDownload(a))
  ) {
    notificationNew = true;
    renderUpdates();
    setTimeout(() => toast(t("newRelease")), 1300);
  } else if (!seen && build.fingerprint)
    store.set("hs-release-seen", build.fingerprint);
  checkUpdates();
})();
