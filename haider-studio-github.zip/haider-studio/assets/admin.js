/* Browser-local editorial tools. The visible client-side PIN is not authentication. */
(() => {
  "use strict";
  const STORAGE_KEY = "hs-studio-content";
  const declared = (
    Array.isArray(window.HAIDER_APPS) ? window.HAIDER_APPS : []
  ).filter(
    (app) => typeof app.id === "string" && /^[a-z0-9][a-z0-9-]*$/.test(app.id),
  );
  const appIds = [...new Set(declared.map((app) => app.id))];
  if (
    document.body.dataset.page !== "home" ||
    !appIds.length ||
    !document.querySelector(".header .brand")
  )
    return;
  let unlocked = false,
    taps = 0,
    lastTap = 0,
    trigger = null,
    dirty = false,
    feedbackKey = "";
  const strings = {
    ar: {
      access: "دخول لوحة الاستوديو",
      pinLabel: "رمز الدخول",
      pinHelp: "أدخل رمز لوحة التحرير المحلية.",
      unlock: "فتح اللوحة",
      cancel: "إلغاء",
      wrong: "الرمز غير صحيح. حاول مجددًا.",
      editor: "لوحة الاستوديو",
      eyebrow: "HAIDER STUDIO · LOCAL EDITOR",
      lock: "إغلاق وقفل",
      intro:
        "عدّل النصوص بالعربية والإنجليزية، ثم احفظها على هذا المتصفح أو صدّرها للنشر.",
      localNotice:
        "هذه لوحة محلية، وليست إدارة آمنة للخادم. الرمز موجود في JavaScript ولا يحمي معلومات سرية. لا تضع أسرارًا هنا.",
      publishNotice:
        "الحفظ يؤثر في هذا المتصفح فقط. للنشر للجميع: صدّر studio-content.json، واستبدل به assets/studio-content.json، ثم أعد بناء الموقع ونشره.",
      hero: "واجهة الترحيب",
      montage: "قسم المونتاج",
      apps: "تطبيقات المونتاج",
      arabic: "العربية",
      english: "English",
      firstTitle: "السطر الأول للعنوان",
      secondTitle: "السطر الذهبي للعنوان",
      title: "العنوان",
      description: "الوصف",
      appName: "اسم التطبيق",
      filesNotice:
        "هذه اللوحة تعدّل النصوص فقط. حالة الملفات وروابط التحميل والأحجام والإصدارات تبقى ناتجة عن الملفات الأصلية وفحص البناء.",
      save: "حفظ على هذا المتصفح",
      reset: "استعادة المحتوى المنشور",
      export: "تصدير JSON للنشر",
      import: "استيراد JSON",
      saved:
        "حُفظت التعديلات على هذا المتصفح فقط. صدّر الملف وانشره لتظهر للجميع.",
      resetDone: "أزيلت التعديلات المحلية واستُعيد المحتوى المنشور.",
      exported:
        "جُهّز ملف التصدير. استبدل assets/studio-content.json به، ثم أعد البناء والنشر.",
      imported:
        "حُمّل الملف في حقول اللوحة فقط. اضغط حفظ لتطبيقه محليًا؛ لم يُنشر.",
      invalid:
        "الملف أو المحتوى لا يطابق البنية المطلوبة، أو يتجاوز حدود النص. لم تُطبّق تغييرات.",
      storage:
        "تعذّر الحفظ في التخزين المحلي. لم تُحفظ التغييرات؛ يمكنك تصديرها إلى ملف JSON.",
      tooLarge: "الملف أكبر من الحد المسموح (64 كيلوبايت).",
      readError: "تعذّرت قراءة الملف. اختر ملف JSON صالحًا.",
      unsaved: "توجد تعديلات في الحقول لم تُحفظ بعد.",
      maxHint: "حتى 120 حرفًا للعناوين والأسماء، و2000 حرف للأوصاف.",
      emptyImport: "اختر ملف studio-content.json صالحًا.",
    },
    en: {
      access: "Studio editor access",
      pinLabel: "Access code",
      pinHelp: "Enter the code for the local editor.",
      unlock: "Open editor",
      cancel: "Cancel",
      wrong: "Incorrect code. Please try again.",
      editor: "Studio editor",
      eyebrow: "HAIDER STUDIO · LOCAL EDITOR",
      lock: "Close and lock",
      intro:
        "Edit Arabic and English copy, then save it in this browser or export it for publishing.",
      localNotice:
        "This is a local editor, not secure server administration. The code is visible in JavaScript and does not protect secrets. Do not enter confidential information.",
      publishNotice:
        "Saving affects this browser only. To publish for everyone, export studio-content.json, replace assets/studio-content.json with it, then rebuild and deploy the site.",
      hero: "Welcome section",
      montage: "Montage section",
      apps: "Montage applications",
      arabic: "العربية",
      english: "English",
      firstTitle: "First title line",
      secondTitle: "Gold title line",
      title: "Title",
      description: "Description",
      appName: "Application name",
      filesNotice:
        "This editor changes text only. File availability, download URLs, sizes and versions still come from original packages and build verification.",
      save: "Save in this browser",
      reset: "Restore published content",
      export: "Export JSON for publishing",
      import: "Import JSON",
      saved:
        "Changes saved in this browser only. Export and deploy the file to publish them for everyone.",
      resetDone: "Local overrides removed. Published content restored.",
      exported:
        "Export prepared. Replace assets/studio-content.json with the file, then rebuild and deploy.",
      imported:
        "File loaded into the editor fields only. Save to apply locally; nothing has been published.",
      invalid:
        "The file or content has an invalid structure or exceeds text limits. No changes were applied.",
      storage:
        "Local storage is unavailable. Changes were not saved; you can export them as JSON.",
      tooLarge: "The file exceeds the 64 KB limit.",
      readError: "The file could not be read. Choose a valid JSON file.",
      unsaved: "The fields contain changes that have not been saved.",
      maxHint:
        "Titles and names: up to 120 characters. Descriptions: up to 2,000 characters.",
      emptyImport: "Choose a valid studio-content.json file.",
    },
  };
  const language = () => (document.documentElement.lang === "en" ? "en" : "ar");
  const text = (key) => strings[language()][key] || key;
  const isObject = (value) =>
    value !== null &&
    typeof value === "object" &&
    !Array.isArray(value) &&
    (Object.getPrototypeOf(value) === Object.prototype ||
      Object.getPrototypeOf(value) === null);
  function shape(value, keys) {
    if (
      !isObject(value) ||
      Object.keys(value).length !== keys.length ||
      !keys.every((key) => Object.prototype.hasOwnProperty.call(value, key))
    )
      throw new Error("shape");
  }
  function plain(value, maximum) {
    if (
      typeof value !== "string" ||
      value.length > maximum ||
      /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value)
    )
      throw new Error("text");
    return value;
  }
  function validate(value) {
    shape(value, ["schemaVersion", "hero", "montage", "apps"]);
    if (value.schemaVersion !== 1) throw new Error("version");
    shape(value.hero, ["ar", "en"]);
    shape(value.montage, ["ar", "en"]);
    shape(value.apps, appIds);
    const output = { schemaVersion: 1, hero: {}, montage: {}, apps: {} };
    for (const lang of ["ar", "en"]) {
      shape(value.hero[lang], ["title1", "title2", "description"]);
      shape(value.montage[lang], ["title", "description"]);
      output.hero[lang] = {
        title1: plain(value.hero[lang].title1, 120),
        title2: plain(value.hero[lang].title2, 120),
        description: plain(value.hero[lang].description, 2000),
      };
      output.montage[lang] = {
        title: plain(value.montage[lang].title, 120),
        description: plain(value.montage[lang].description, 2000),
      };
    }
    for (const id of appIds) {
      shape(value.apps[id], ["name", "description"]);
      shape(value.apps[id].description, ["ar", "en"]);
      output.apps[id] = {
        name: plain(value.apps[id].name, 120),
        description: {
          ar: plain(value.apps[id].description.ar, 2000),
          en: plain(value.apps[id].description.en, 2000),
        },
      };
    }
    return output;
  }
  function fallback() {
    const apps = {};
    declared.forEach(
      (app) =>
        (apps[app.id] = {
          name:
            typeof app.name === "string"
              ? app.name.slice(0, 120)
              : "Haider Studio",
          description: {
            ar:
              typeof app.description?.ar === "string"
                ? app.description.ar.slice(0, 2000)
                : "",
            en:
              typeof app.description?.en === "string"
                ? app.description.en.slice(0, 2000)
                : "",
          },
        }),
    );
    return {
      schemaVersion: 1,
      hero: {
        ar: { title1: "تجربة تستحق", title2: "التميّز.", description: "" },
        en: {
          title1: "An experience",
          title2: "that stands out.",
          description: "",
        },
      },
      montage: {
        ar: { title: "المونتاج", description: "" },
        en: { title: "Montage", description: "" },
      },
      apps,
    };
  }
  function defaults() {
    try {
      return validate(window.HAIDER_DEFAULT_CONTENT);
    } catch {
      return validate(fallback());
    }
  }
  function current() {
    try {
      return validate(window.HAIDER_CONTENT);
    } catch {}
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return validate(JSON.parse(saved));
    } catch {}
    return defaults();
  }
  function node(tag, className, labelKey) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (labelKey) {
      element.dataset.adminI18n = labelKey;
      element.textContent = text(labelKey);
    }
    return element;
  }
  function button(action, labelKey, className = "hs-admin-button") {
    const element = node("button", className, labelKey);
    element.type = "button";
    element.dataset.adminAction = action;
    return element;
  }
  const pinDialog = node("dialog", "hs-admin-dialog hs-admin-pin-dialog");
  pinDialog.id = "hs-admin-pin-dialog";
  pinDialog.setAttribute("aria-labelledby", "hs-admin-pin-title");
  const pinHeader = node("div", "hs-admin-pin-heading");
  const pinMark = node("span", "hs-admin-mark");
  pinMark.textContent = "✦";
  pinMark.setAttribute("aria-hidden", "true");
  pinHeader.append(pinMark);
  const pinTitle = node("h2", "", "access");
  pinTitle.id = "hs-admin-pin-title";
  pinHeader.append(pinTitle);
  pinDialog.append(pinHeader);
  const pinHelp = node("p", "hs-admin-copy", "pinHelp");
  pinHelp.id = "hs-admin-pin-help";
  pinDialog.append(pinHelp);
  const pinNotice = node("p", "hs-admin-notice", "localNotice");
  pinDialog.append(pinNotice);
  const pinForm = node("form", "hs-admin-pin-form");
  pinForm.id = "hs-admin-pin-form";
  const pinLabel = node("label", "hs-admin-label");
  const pinLabelText = node("span", "", "pinLabel");
  const pinInput = document.createElement("input");
  pinInput.id = "hs-admin-pin";
  pinInput.name = "pin";
  pinInput.type = "password";
  pinInput.inputMode = "numeric";
  pinInput.autocomplete = "off";
  pinInput.maxLength = 4;
  pinInput.pattern = "[0-9]{4}";
  pinInput.required = true;
  pinInput.dir = "ltr";
  pinInput.setAttribute(
    "aria-describedby",
    "hs-admin-pin-help hs-admin-pin-error",
  );
  pinLabel.append(pinLabelText, pinInput);
  pinForm.append(pinLabel);
  const pinError = node("p", "hs-admin-feedback");
  pinError.id = "hs-admin-pin-error";
  pinError.setAttribute("role", "status");
  pinError.setAttribute("aria-live", "polite");
  pinForm.append(pinError);
  const pinActions = node("div", "hs-admin-actions");
  const unlockButton = button(
    "unlock",
    "unlock",
    "hs-admin-button hs-admin-button-gold",
  );
  unlockButton.type = "submit";
  const cancelButton = button("cancel", "cancel");
  pinActions.append(unlockButton, cancelButton);
  pinForm.append(pinActions);
  pinDialog.append(pinForm);
  const editor = node("dialog", "hs-admin-dialog hs-admin-editor");
  editor.id = "hs-admin-editor";
  editor.setAttribute("aria-labelledby", "hs-admin-title");
  editor.setAttribute("aria-describedby", "hs-admin-intro");
  const header = node("header", "hs-admin-header");
  const headingGroup = node("div", "");
  headingGroup.append(node("div", "hs-admin-eyebrow", "eyebrow"));
  const title = node("h2", "", "editor");
  title.id = "hs-admin-title";
  headingGroup.append(title);
  header.append(
    headingGroup,
    button("lock", "lock", "hs-admin-button hs-admin-lock"),
  );
  editor.append(header);
  const body = node("div", "hs-admin-body");
  const intro = node("p", "hs-admin-copy", "intro");
  intro.id = "hs-admin-intro";
  body.append(
    intro,
    node("p", "hs-admin-notice", "localNotice"),
    node("p", "hs-admin-publish-notice", "publishNotice"),
  );
  const editorForm = node("form", "hs-admin-form");
  editorForm.id = "hs-admin-form";
  const fields = new Map();
  function field(path, labelKey, textarea = false, dir = "auto") {
    const label = node("label", "hs-admin-label");
    label.append(node("span", "", labelKey));
    const input = document.createElement(textarea ? "textarea" : "input");
    input.name = path;
    input.id = "hs-admin-field-" + path.replace(/\./g, "-");
    input.maxLength = textarea ? 2000 : 120;
    input.dir = dir;
    input.spellcheck = true;
    if (textarea) input.rows = 3;
    else input.type = "text";
    input.autocomplete = "off";
    label.append(input);
    fields.set(path, input);
    return label;
  }
  function section(labelKey) {
    const fieldset = node("fieldset", "hs-admin-section");
    fieldset.append(node("legend", "", labelKey));
    editorForm.append(fieldset);
    return fieldset;
  }
  function languageColumn(parent, lang) {
    const column = node("div", "hs-admin-language-column");
    column.dir = lang === "ar" ? "rtl" : "ltr";
    column.append(
      node(
        "h3",
        "hs-admin-language-heading",
        lang === "ar" ? "arabic" : "english",
      ),
    );
    parent.append(column);
    return column;
  }
  const hero = section("hero");
  const heroGrid = node("div", "hs-admin-language-grid");
  hero.append(heroGrid);
  for (const lang of ["ar", "en"]) {
    const column = languageColumn(heroGrid, lang);
    column.append(
      field(
        `hero.${lang}.title1`,
        "firstTitle",
        false,
        lang === "ar" ? "rtl" : "ltr",
      ),
      field(
        `hero.${lang}.title2`,
        "secondTitle",
        false,
        lang === "ar" ? "rtl" : "ltr",
      ),
      field(
        `hero.${lang}.description`,
        "description",
        true,
        lang === "ar" ? "rtl" : "ltr",
      ),
    );
  }
  const montage = section("montage");
  const montageGrid = node("div", "hs-admin-language-grid");
  montage.append(montageGrid);
  for (const lang of ["ar", "en"]) {
    const column = languageColumn(montageGrid, lang);
    column.append(
      field(
        `montage.${lang}.title`,
        "title",
        false,
        lang === "ar" ? "rtl" : "ltr",
      ),
      field(
        `montage.${lang}.description`,
        "description",
        true,
        lang === "ar" ? "rtl" : "ltr",
      ),
    );
  }
  const appsSection = section("apps");
  appsSection.append(
    node("p", "hs-admin-copy hs-admin-files-notice", "filesNotice"),
  );
  for (const id of appIds) {
    const group = node("div", "hs-admin-app-group");
    const caption = node("h3", "hs-admin-app-heading");
    const app = declared.find((item) => item.id === id);
    caption.textContent = `${app?.platform === "ios" ? "iOS" : app?.platform === "android" ? "Android" : id} · ${id}`;
    caption.dir = "ltr";
    group.append(caption, field(`apps.${id}.name`, "appName"));
    const grid = node("div", "hs-admin-language-grid");
    group.append(grid);
    for (const lang of ["ar", "en"]) {
      const column = languageColumn(grid, lang);
      column.append(
        field(
          `apps.${id}.description.${lang}`,
          "description",
          true,
          lang === "ar" ? "rtl" : "ltr",
        ),
      );
    }
    appsSection.append(group);
  }
  const hint = node("p", "hs-admin-copy hs-admin-limit-hint", "maxHint");
  editorForm.append(hint);
  const status = node("p", "hs-admin-feedback");
  status.id = "hs-admin-status";
  status.setAttribute("role", "status");
  status.setAttribute("aria-live", "polite");
  editorForm.append(status);
  const actions = node("div", "hs-admin-editor-actions");
  const saveButton = button(
    "save",
    "save",
    "hs-admin-button hs-admin-button-gold",
  );
  saveButton.type = "submit";
  actions.append(
    saveButton,
    button("export", "export"),
    button("import", "import"),
    button("reset", "reset", "hs-admin-button hs-admin-reset"),
  );
  editorForm.append(actions);
  const importInput = document.createElement("input");
  importInput.type = "file";
  importInput.accept = ".json,application/json";
  importInput.id = "hs-admin-import";
  importInput.hidden = true;
  importInput.setAttribute("aria-label", text("import"));
  editorForm.append(importInput);
  body.append(editorForm);
  editor.append(body);
  document.body.append(pinDialog, editor);
  function fill(content) {
    for (const [path, input] of fields) {
      const value = path
        .split(".")
        .reduce((value, key) => value?.[key], content);
      input.value = typeof value === "string" ? value : "";
    }
    dirty = false;
  }
  function read() {
    const content = {
      schemaVersion: 1,
      hero: { ar: {}, en: {} },
      montage: { ar: {}, en: {} },
      apps: {},
    };
    appIds.forEach(
      (id) =>
        (content.apps[id] = { name: "", description: { ar: "", en: "" } }),
    );
    for (const [path, input] of fields) {
      const keys = path.split(".");
      const last = keys.pop();
      const parent = keys.reduce((value, key) => value[key], content);
      parent[last] = input.value;
    }
    return validate(content);
  }
  function feedback(key, error = false) {
    feedbackKey = key;
    status.textContent = text(key);
    status.classList.toggle("hs-admin-feedback-error", error);
  }
  function dispatch(content) {
    window.dispatchEvent(
      new CustomEvent("haider:content-change", { detail: content }),
    );
  }
  function updateLabels() {
    const lang = language();
    pinDialog.lang = editor.lang = lang;
    pinDialog.dir = editor.dir = lang === "ar" ? "rtl" : "ltr";
    document
      .querySelectorAll("[data-admin-i18n]")
      .forEach(
        (element) => (element.textContent = text(element.dataset.adminI18n)),
      );
    if (feedbackKey) status.textContent = text(feedbackKey);
    if (pinError.dataset.error) pinError.textContent = text("wrong");
    importInput.setAttribute("aria-label", text("import"));
  }
  function lock() {
    unlocked = false;
    taps = 0;
    lastTap = 0;
    pinInput.value = "";
    pinError.textContent = "";
    delete pinError.dataset.error;
    if (editor.open) editor.close();
    if (pinDialog.open) pinDialog.close();
    trigger?.focus({ preventScroll: true });
  }
  function openPin(source) {
    trigger = source;
    unlocked = false;
    pinInput.value = "";
    pinError.textContent = "";
    delete pinError.dataset.error;
    updateLabels();
    pinDialog.showModal();
    pinInput.focus();
  }
  function openEditor() {
    fill(current());
    feedbackKey = "";
    status.textContent = "";
    updateLabels();
    editor.showModal();
    editor.scrollTop = 0;
    const first = fields.values().next().value;
    first?.focus({ preventScroll: true });
  }
  pinForm.addEventListener("submit", (event) => {
    event.preventDefault();
    if (pinInput.value !== "8181") {
      pinError.textContent = text("wrong");
      pinError.dataset.error = "true";
      pinInput.value = "";
      pinInput.focus();
      return;
    }
    unlocked = true;
    pinDialog.close();
    openEditor();
  });
  cancelButton.addEventListener("click", lock);
  pinDialog.addEventListener("cancel", () => {
    unlocked = false;
    taps = 0;
    lastTap = 0;
  });
  pinDialog.addEventListener("close", () => {
    pinInput.value = "";
    if (!unlocked) trigger?.focus({ preventScroll: true });
  });
  editor.addEventListener("cancel", () => {
    unlocked = false;
    taps = 0;
    lastTap = 0;
  });
  editor.addEventListener("close", () => {
    unlocked = false;
    taps = 0;
    lastTap = 0;
    pinInput.value = "";
    trigger?.focus({ preventScroll: true });
  });
  editorForm.addEventListener("input", () => {
    dirty = true;
    feedback("unsaved");
  });
  editorForm.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!unlocked) return;
    let content;
    try {
      content = read();
    } catch {
      feedback("invalid", true);
      return;
    }
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(content));
    } catch {
      feedback("storage", true);
      return;
    }
    dirty = false;
    dispatch(content);
    feedback("saved");
  });
  editor.addEventListener("click", (event) => {
    const action = event.target.closest("[data-admin-action]")?.dataset
      .adminAction;
    if (!action || !unlocked) return;
    if (action === "lock") {
      lock();
      return;
    }
    if (action === "import") {
      importInput.value = "";
      importInput.click();
      return;
    }
    if (action === "reset") {
      const content = defaults();
      try {
        localStorage.removeItem(STORAGE_KEY);
      } catch {
        feedback("storage", true);
        return;
      }
      fill(content);
      dispatch(content);
      feedback("resetDone");
      return;
    }
    if (action === "export") {
      let content;
      try {
        content = read();
      } catch {
        feedback("invalid", true);
        return;
      }
      const blob = new Blob([JSON.stringify(content, null, 2) + "\n"], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "studio-content.json";
      document.body.append(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      feedback("exported");
    }
  });
  importInput.addEventListener("change", async () => {
    if (!unlocked) return;
    const file = importInput.files?.[0];
    if (!file) return;
    if (file.size > 65536) {
      feedback("tooLarge", true);
      return;
    }
    let content;
    try {
      content = validate(JSON.parse(await file.text()));
    } catch {
      feedback("invalid", true);
      return;
    }
    if (!unlocked || !editor.open) return;
    fill(content);
    dirty = true;
    feedback("imported");
  });
  document.addEventListener(
    "click",
    (event) => {
      const brand = event.target.closest(".header .brand");
      if (!brand) {
        if (!pinDialog.open && !editor.open) taps = 0;
        return;
      }
      if (
        event.button !== 0 ||
        event.ctrlKey ||
        event.metaKey ||
        event.shiftKey ||
        event.altKey
      )
        return;
      event.preventDefault();
      if (editor.open || pinDialog.open) return;
      const now = Date.now();
      taps = now - lastTap <= 4000 ? taps + 1 : 1;
      lastTap = now;
      if (document.body.dataset.page === "home") window.scrollTo(0, 0);
      if (taps >= 7) {
        taps = 0;
        lastTap = 0;
        openPin(brand);
      }
    },
    true,
  );
  window.addEventListener("pagehide", lock);
  new MutationObserver(updateLabels).observe(document.documentElement, {
    attributes: true,
    attributeFilter: ["lang"],
  });
  updateLabels();
})();
