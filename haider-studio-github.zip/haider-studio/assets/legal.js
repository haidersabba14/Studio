(() => {
  const readLanguage = () => {
    try {
      return localStorage.getItem("hs-language") === "en" ? "en" : "ar";
    } catch {
      return "ar";
    }
  };
  function setLanguage(lang) {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    document.querySelectorAll("[data-lang]").forEach((el) => {
      el.hidden = el.dataset.lang !== lang;
    });
    document.querySelectorAll("[data-language]").forEach((button) => {
      button.textContent = lang === "ar" ? "English" : "العربية";
      button.setAttribute(
        "aria-label",
        lang === "ar" ? "Switch to English" : "التبديل إلى العربية",
      );
    });
    const title = document.querySelector('main [data-lang="' + lang + '"] h1');
    if (title) document.title = title.textContent + " — HAIDER STUDIO";
    try {
      localStorage.setItem("hs-language", lang);
    } catch {}
  }
  setLanguage(readLanguage());
  document
    .querySelectorAll("[data-language]")
    .forEach((button) =>
      button.addEventListener("click", () =>
        setLanguage(document.documentElement.lang === "ar" ? "en" : "ar"),
      ),
    );
})();
