# HAIDER STUDIO

موقع عربي وإنجليزي باللونين الأسود والذهبي، مبني باستخدام HTML وCSS وJavaScript ويعمل كملفات ثابتة على GitHub Pages. لا يحتاج إلى قاعدة بيانات أو خادم تطبيقات. أدوات التجهيز مكتوبة ببايثون وتعمل محليًا أو داخل GitHub Actions.

الشعار المعروض هو التصميم الذهبي على الأسود الذي اعتمده المستخدم، محفوظ في `assets/haider-logo-gold.png`. يُستخدم شعارًا للاستوديو؛ وليس أيقونة مستخرجة من ملفات التطبيقات.

## حالة الملفات عند التسليم

**أُرفق ملف iOS الأصلي `HaiderStudio.ipa` وأُدرج دون تعديل في المشروع.** رابط تنزيله يعتمد على الملف الحقيقي. ملف أندرويد `app-debug.apk` لم يُرفق بعد؛ تظهر نسخته بحالة **قريبًا**، ويبقى تنزيله ونسخ رابطه معطّلين حتى إضافته. لا يتضمن المشروع ملفات بديلة أو بيانات تنزيل مصطنعة.

بيانات IPA المقروءة من الحزمة: الإصدار `1.0.0`، البناء `1`، الحد الأدنى iOS `17.0`، المعرّف `com.haiderstudio.ultimate`، وأجهزة iPhone (`UIDeviceFamily: [1]`). الحجم الفعلي `1,644,751` بايت، وبصمة SHA-256:

```text
6c004d1e9eada071c367515102b4254a1fe1b60d39ce27bdc58bbdf0541ae759
```

هذه معلومات الحزمة، وليست اعتمادًا لصحة التوقيع أو نجاح التثبيت على الجهاز.

الملف الأول موجود بالفعل. أضف ملف أندرويد الأصلي إلى المسار الثاني عند توفره:

```text
downloads/HaiderStudio.ipa
downloads/app-debug.apk
```

ثم أعد تجهيز المشروع. تُقرأ معلومات الإصدار والتوافق من `Info.plist` داخل IPA ومن `AndroidManifest.xml` داخل APK حيث تتوفر، ويُحسب حجم الملف وبصمة SHA-256 من محتواه الحقيقي. إذا كان الملف تالفًا أو تعذر استخراج معلوماته، راجع ناتج أمر التجهيز قبل النشر. الملف `app-debug.apk` قد يكون إصدار تطوير؛ راجع ملاءمته للتوزيع.

## التجهيز والمعاينة

المتطلب الأساسي Python 3.10 أو أحدث. Node.js اختياري لتشغيل أوامر npm المختصرة؛ لا توجد حزم تشغيل تُثبّت عبر npm.

```sh
python3 scripts/build.py
python3 -m http.server 8000 --directory dist
```

افتح `http://localhost:8000`. استخدم خادم ملفات محليًا بدل فتح HTML مباشرة، حتى تعمل طلبات فحص الروابط بنفس سلوك الاستضافة. الملفات الجاهزة للنشر في `dist/`، وملفات المصدر في جذر المشروع.

أوامر npm المختصرة (مع تثبيت Node.js):

```sh
npm run build
npm run check
```

للتحقق من وجود الملفين قبل النشر:

```sh
python3 scripts/build.py --require-files
```

ما زال هذا الأمر يفشل حاليًا لأن `app-debug.apk` غير موجود، رغم توفر IPA الحقيقي. راجع دائمًا سجل التنفيذ؛ نجاح تجهيز الواجهة في الوضع الافتراضي لا يعني اكتمال جميع ملفات التطبيقات.

## النشر على GitHub Pages

1. ارفع محتويات المشروع إلى مستودع GitHub، مع الحفاظ على مجلد `.github/workflows/`.
2. في المستودع افتح **Settings → Pages → Build and deployment → Source** واختر **GitHub Actions**.
3. ادفع تغييراتك إلى الفرع الذي يحدده ملف `.github/workflows/pages.yml`، أو شغّل workflow يدويًا من تبويب Actions.
4. بعد نجاح التنفيذ، افتح رابط النشر الذي يظهر في نتيجة Actions.
5. اختبر البحث والتصفية وصفحتي التطبيقات وروابط تنزيل الملفات المنشورة على جهاز حقيقي.

ينشئ workflow مجلد `dist/` وينشره، ولا يحتاج إلى تعيين أسرار GitHub لتنزيلات محلية. تدعم الروابط النسبية مواقع المشاريع مثل `https://USER.github.io/REPO/`. يجهّز السكربت مسار صفحة 404 من اسم المستودع في GitHub Actions أو من `siteUrl` عند تحديده.

عند النشر يدويًا على استضافة أخرى، انشر **محتويات** `dist/`، واضبط `siteUrl` على عنوان الموقع النهائي قبل البناء لتوليد روابط SEO و404 المناسبة. لا تفترض وجود صفحة فهرسة لمحركات البحث قبل تعيين العنوان الصحيح.

## الإعدادات

عدّل `config.json` ثم شغّل التجهيز مجددًا. مثال:

```json
{
  "contactEndpoint": null,
  "contactEmail": null,
  "siteUrl": "https://USER.github.io/REPO/",
  "externalDownloads": {}
}
```

- `siteUrl`: العنوان النهائي باستخدام HTTPS، مع مسار المستودع إن وجد. يبقى `null` للمعاينة المحلية.
- `contactEndpoint`: عنوان استقبال رسائل HTTPS لخدمة نماذج تدعم الطلبات من المتصفح وCORS، أو `null`.
- `contactEmail`: بريد تواصل حقيقي تملكه، أو `null`.
- `externalDownloads`: روابط HTTPS مباشرة اختيارية لكل نظام، بالمفتاحين `ios` و`android`.
- `externalSha256`: كائن اختياري لتثبيت بصمة SHA-256 الموثوقة للملفات الخارجية بالمفتاحين نفسيهما.

هذه إعدادات **عامة** تُضمَّن في ملفات الموقع ويمكن للزوار قراءتها. لا تضع فيها كلمات مرور أو مفاتيح API سرية. ربط خدمة خارجية قد يتطلب إعداد الحساب والنطاق لدى مزود الخدمة؛ مراجعة شروط الخدمة وحدود خطتها مسؤولية الناشر.

## الملفات الكبيرة والاستضافة المجانية

GitHub يمنع الملفات الأكبر من 100 MiB في Git العادي، وتوصيته أن تبقى الملفات أصغر من 50 MiB. الحد الأقصى لحجم ملف واحد على Cloudflare Pages هو 25 MiB. راجع الحدود الحالية لدى المزود قبل اختيار الاستضافة.

للملفات الكبيرة، استخدم مثلًا **GitHub Releases** مع إبقاء الموقع على GitHub Pages. ارفع الملفات الأصلية كأصول إصدار، ثم ضع الروابط المباشرة في الإعدادات:

```json
{
  "contactEndpoint": null,
  "contactEmail": null,
  "siteUrl": "https://USER.github.io/REPO/",
  "externalDownloads": {
    "ios": "https://github.com/USER/REPO/releases/download/v1/HaiderStudio.ipa",
    "android": "https://github.com/USER/REPO/releases/download/v1/app-debug.apk"
  }
}
```

استبدل جميع القيم المثال بمستودعك وإصدارك الفعلي. إذا كان الملف الأصلي موجودًا محليًا، يتحقق السكربت من رابط HTTPS بتنزيل المحتوى وحساب حجمه وبصمته ومقارنته بالملف الأصلي. إذا لم يوجد محليًا، يجلب السكربت الملف من الرابط المصرح به في الإعدادات إلى مساحة مؤقتة، ويستخرج بياناته الحقيقية ثم يحذف النسخة المؤقتة. يعمل المسار الثاني داخل GitHub Actions دون إدخال الملفات الكبيرة في Git. عدم التطابق أو فشل الوصول يعطّل التنزيل. يحتاج تجهيز الملفات الخارجية إلى اتصال إنترنت وقد يستغرق وقتًا بحسب حجمها؛ الحد المسموح لكل ملف أثناء الجلب هو 2 GiB.

يُستحسن تثبيت هوية الملف بإضافة كائن `externalSha256` إلى `config.json` بالمفتاحين `ios` و/أو `android`، وقيمة البصمة الصحيحة المكوّنة من 64 حرفًا سداسيًا لكل ملف. احصل عليها من ملفك الأصلي أو من بيانات `assets/apps.json` بعد تجهيز نسخة موثوقة. يرفض السكربت رابطًا يختلف محتواه عن البصمة المحددة. لا تستخدم بصمة مثال عشوائية. لا تُدخل الملفات الكبيرة في Git لمجرد استخراج بياناتها. تحقق من عمل الروابط العامة ومن سلوك الاستضافة مع المتصفح. خدمات التخزين وReleases لها سياسات استخدام وحدود قد تتغير؛ مجانية الاستضافة ليست ضمانًا لسعة غير محدودة.

## قسم المونتاج

مكتبة التطبيقات موجودة داخل قسم **المونتاج / Montage**. هذا اسم قسم مكتبة التطبيقات، وليس معرض أعمال فيديو. توجد داخله نسخة iOS الأصلية المتاحة، ونسخة أندرويد بحالة **قريبًا / Coming soon** حتى إرفاق ملف APK الحقيقي.

## ما يعمل دون خادم

- العربية والإنجليزية واتجاه الصفحة المناسب لكل لغة.
- بحث فوري وتصفية حسب نظام التشغيل.
- صفحات تفاصيل مستقلة وروابط تنقل داخلية.
- اقتراح النظام بحسب المتصفح، مع إتاحة اختيار النظام الآخر يدويًا.
- نسخ ومشاركة الروابط المتاحة فقط.
- حفظ تفضيلات العرض محليًا وعرض إشعارات الإصدارات داخل الموقع عند تغير بيانات الإصدار بين الزيارات.
- رابط العودة للأعلى، وقوائم الأسئلة الشائعة، وصفحات الخصوصية والشروط و404.
- تصميم متجاوب ومراعاة تقليل الحركة وإمكانية الوصول.

لا ينشئ الموقع عداد تنزيلات أو تقييمات، ولا يطلب صلاحية إشعارات النظام. اكتشاف النظام تقديري لأن بعض المتصفحات تخفي نوع الجهاز. تحديثات الإصدارات ليست Push Notifications؛ يظهر التغيير عند فتح الموقع أو إعادة تحميله بعد نشر البيانات الجديدة.

## تحرير المحتوى محليًا

تتوفر لوحة تحرير محلية في الصفحة الرئيسية. للوصول إليها:

1. انقر شعار الاستوديو في شريط التنقل **7 مرات متتالية**، بفاصل لا يتجاوز **4 ثوانٍ** بين كل نقرتين.
2. أدخل الرمز **8181** لفتح المحرر.
3. عدّل العناوين والأوصاف العربية والإنجليزية للواجهة الرئيسية وقسم المونتاج، وأسماء التطبيقات وأوصافها، ثم احفظ.

الرمز موجود في JavaScript العام، ويمكن لأي زائر الاطلاع عليه. هذه بوابة عرض محلية لتسهيل الوصول إلى المحرر، وليست مصادقة أو لوحة إدارة خلفية آمنة. لا تضع أسرارًا في المحتوى أو رمز الدخول. لا تعدّل اللوحة ملف IPA أو بيانات الإصدار أو الحجم أو البصمة أو روابط التنزيل.

يحفظ زر الحفظ التعديلات تحت المفتاح `hs-studio-content` في `localStorage`؛ تظهر فقط في المتصفح نفسه وعلى أصل الموقع نفسه. لا ترسل اللوحة بيانات إلى خادم ولا تغيّر الموقع المنشور لبقية الزوار. عند إغلاق اللوحة تُقفل حالة التحرير المؤقتة؛ يتطلب فتحها مجددًا النقرات السبع والرمز. لا توجد لوحة تحرير في صفحات السياسات.

لنشر المحتوى لجميع الزوار:

1. صدّر المحتوى من اللوحة لتنزيل `studio-content.json`.
2. استبدل الملف `assets/studio-content.json` في مصدر المشروع بالملف المصدّر.
3. شغّل `python3 scripts/build.py`، ثم أعد نشر `dist/`، أو ادفع الملف إلى المستودع لتشغيل GitHub Actions.

يمكن استيراد ملف محتوى إلى اللوحة؛ يُرفض الملف الذي يتضمن مفاتيح غير مسموحة أو قيمًا لا تطابق الحقول النصية المتوقعة. الاستيراد نفسه لا ينشر شيئًا. يعيد زر إعادة الضبط المحتوى الافتراضي المنشور ويحذف التعديلات المحلية؛ يمكن كذلك حذفها من إعدادات بيانات الموقع في المتصفح. عند التحقق من نسخة منشورة جديدة، أعد ضبط التعديلات المحلية أو افتح متصفحًا آخر حتى لا تغطي التعديلات المحفوظة على المحتوى المنشور.

## التواصل والخصوصية

عند غياب إعدادات خدمة التواصل، لا يدّعي النموذج إرسال الرسالة. تتوفر المسودة المحلية بحسب واجهة النموذج. لتفعيل إرسال حقيقي، اربط endpoint مناسبًا واختبره من عنوان الموقع المنشور؛ وجود رابط endpoint وحده لا يضمن تهيئة CORS أو قبول الحقول لدى المزوّد. عنوان البريد الاختياري يفتح برنامج البريد لدى المستخدم ويحتاج إتمام الإرسال منه.

لا تُفعّل تحليلات افتراضيًا. قد يعالج مزوّد الاستضافة سجلات الطلبات وفق سياسته. صفحات `privacy.html` و`terms.html` تشرح سلوك الموقع العام؛ راجعها وعدّلها عند توصيل خدمة فعلية أو تغيير طريقة توزيع التطبيقات. سياسة موقع التنزيل لا تغني عن سياسة الخصوصية الخاصة بكل تطبيق.

## تثبيت التطبيقات

- **iOS / iPadOS:** تنزيل IPA لا يثبت التطبيق تلقائيًا. تحتاج إلى توقيع وطريقة تثبيت متوافقين مع الجهاز وسياسات Apple. المشروع لا يوفر توقيعًا أو شهادة توزيع.
- **Android:** استخدم ملف APK موثوق المصدر واتبع تعليمات النظام لإذن تثبيت الملف. لا تُطلب أذونات إضافية من الموقع. لا تتجاوز تحذيرات الجهاز دون فهم مصدر التطبيق وصلاحياته.

## بنية المشروع

```text
index.html                 الواجهة الرئيسية
apps/                      صفحات تفاصيل التطبيقات
privacy.html               سياسة الخصوصية بلغتين
terms.html                 الشروط بلغتين
404.html                   صفحة غير موجودة
assets/                    CSS وJavaScript والرسوم والخطوط والبيانات المولّدة
apps.source.json           تعريف التطبيقات القابل للتوسعة
config.json                إعدادات الاستضافة والتواصل وروابط الملفات
scripts/                   استخراج بيانات الملفات وتجهيز dist
tests/                    اختبارات أدوات التجهيز
downloads/                ملفات التطبيقات الأصلية عند توفيرها
.github/workflows/pages.yml نشر GitHub Pages
dist/                      الناتج الجاهز للنشر بعد التجهيز
```

يُحفظ سجل الإصدارات الحقيقية في `assets/releases.json` دون تواريخ تقديرية. بعد تجهيز إصدار جديد محليًا، أضف هذا الملف المحدّث إلى commit ليبقى السجل محفوظًا في عمليات GitHub Actions اللاحقة؛ لا يكتب سير النشر إلى مستودعك تلقائيًا.

لتوسعة المكتبة، أضف سجلًا إلى `apps.source.json` بمعرّف فريد من الأحرف الإنجليزية الصغيرة والأرقام والشرطة، واسم ونظام `ios` أو `android` واسم ملف ووصف بالعربية والإنجليزية. أضف الملف الأصلي داخل `downloads/` أو رابطه في `externalDownloads` باستخدام المعرّف نفسه. يولّد البناء صفحة التفاصيل تلقائيًا في `dist/apps/ID.html` من قالب النظام، ويمكنك إضافة صفحة مخصصة إلى `apps/ID.html` لتتقدم على القالب. لا تنشر تطبيقًا لا تملك حقوق توزيعه. حقوق العلامة والمحتوى والملفات تعود لأصحابها؛ لم تُضف رخصة تسمح بإعادة توزيع ملفات التطبيقات.

---

# English

HAIDER STUDIO is a bilingual Arabic/English static website built with HTML, CSS, and JavaScript. Python prepares file metadata and the `dist/` deployment folder. No application server or database is required.

The studio logo uses the user-approved gold-on-black design at `assets/haider-logo-gold.png`. It is studio branding, not an icon extracted from the application binaries.

**The original iOS file `HaiderStudio.ipa` is now included unchanged and linked for download.** The Android file `app-debug.apk` is still missing, so Android is labeled **Coming soon** and its download and download-link copying remain unavailable. The project contains no substitute application binaries or fabricated download data.

The supplied IPA reports version `1.0.0`, build `1`, minimum iOS `17.0`, package `com.haiderstudio.ultimate`, and iPhone device family `[1]`. Its exact size is `1,644,751` bytes and SHA-256 is `6c004d1e9eada071c367515102b4254a1fe1b60d39ce27bdc58bbdf0541ae759`. Reading package metadata does not validate its signing certificate or device installation.

The original is already at `downloads/HaiderStudio.ipa`. Add the genuine Android file at `downloads/app-debug.apk` when available, then run:

```sh
python3 scripts/build.py
python3 -m http.server 8000 --directory dist
```

Use Python 3.10 or newer. `npm run build` and `npm run check` are optional Node.js shortcuts. `python3 scripts/build.py --require-files` requires both binaries and currently fails because the Android file is missing. Read build output before publishing. Actual version metadata is read from each application’s manifest, and size and SHA-256 are calculated from actual bytes.

For GitHub Pages, upload the full project, choose **Settings → Pages → Source → GitHub Actions**, and run the included Pages workflow. It prepares and publishes `dist/`. Set `siteUrl` in `config.json` to the full HTTPS deployment URL when building manually, including the repository path for project sites. GitHub Actions can derive the base path from the repository.

`config.json` supports `siteUrl`, `contactEndpoint`, `contactEmail`, and `externalDownloads` (`ios` and `android` direct HTTPS URLs). These values are public; never include secrets. Contact transmission requires a real service configured to accept the browser’s request and fields, including CORS. Email links open the visitor’s mail client. Without a configured service the website does not claim to have sent messages.

For large binaries, use an appropriate download host such as GitHub Releases, and set the direct release-asset URLs under `externalDownloads`. When a local original exists, the build streams the configured HTTPS file and verifies its size and SHA-256 against that original. When the local file is absent, the build fetches the explicitly configured remote package into temporary storage, extracts actual metadata, and removes the temporary file. This works in clean GitHub Actions runners without committing large binaries. Remote fetches are limited to 2 GiB per file and require network access. Optionally add `externalSha256` with `ios` and/or `android` keys containing trusted 64-character lowercase SHA-256 values; a mismatch disables the download. Pinning trusted hashes is recommended. Do not commit files over GitHub’s Git file limit. GitHub blocks ordinary Git files above 100 MiB; Cloudflare Pages limits individual assets to 25 MiB. Provider limits and free plans can change.

The application library is in the **Montage** section; this is the application library, not a video portfolio. The supplied iOS build is available, while Android remains **Coming soon** until the actual APK is provided.

### Local content editor

On the home page, click the header logo **7 consecutive times**, allowing no more than **4 seconds between clicks**, then enter **8181**. The editor changes public Arabic/English hero titles and descriptions, the Montage title and description, and application names and descriptions. It cannot change binaries, download URLs, versions, sizes, or checksums.

This is a client-side convenience gate, not authentication or a secure backend administration panel. The PIN is visible in public JavaScript. Saving writes `hs-studio-content` to this browser’s localStorage and affects only this browser on the same origin. Closing the panel locks the temporary editing state; reopening requires seven clicks and the PIN again. No editor is provided on legal pages.

To publish edits for everyone, export `studio-content.json`, replace `assets/studio-content.json` in the project source, run `python3 scripts/build.py`, and redeploy `dist/` or commit the file for the GitHub Actions workflow. Imports reject unknown keys and invalid field types and do not publish changes. Reset restores the published defaults and removes local edits. Clear local overrides or use another browser when checking a newly published version.

Client-side features include search, platform filters, detail pages, device suggestions, available-link copying and sharing, local display preferences, in-page update notices, FAQs, and bilingual legal pages. Update notices appear after a new version is deployed and revisited; they are not system push notifications. Device suggestions depend on browser information. No analytics or download counter is enabled by default.

Downloading an IPA does not install it: users need a valid signature and a compatible installation method. `app-debug.apk` may be a development build. Review applications and distribution rights before publication. The website’s privacy policy covers the website rather than the applications. Review both legal pages when connecting third-party services. Application files, branding, and content remain subject to their owners’ rights; no redistribution license for application binaries is included.


To extend the library, add a unique lowercase alphanumeric/hyphen ID, name, platform (`ios` or `android`), filename and bilingual description to `apps.source.json`. Add the original to `downloads/` or configure its external URL under the same ID. Missing detail pages are generated in `dist/apps/ID.html` from the platform template; a supplied `apps/ID.html` takes precedence. Commit `assets/releases.json` after release builds to retain verified history across clean CI runs.

Optional browser QA: `tests/browser.cjs` requires Playwright and Chromium in the development environment (not on the deployed website). Set `HAIDER_TEST_URL` to a running static preview; the script uses `/usr/bin/chromium`. Browser fixtures are isolated tests, never production application files. Font licenses are included in `assets/fonts/`.


للتحقق من اللوحة محليًا، بعد تشغيل المعاينة وتوفير Playwright وChromium: `node tests/admin-browser.cjs`. الاختبارات اختيارية في بيئة التطوير ولا يحتاج الموقع المنشور إلى هذه الأدوات.

Local editor browser checks: after starting the static preview with Playwright and Chromium available, run `node tests/admin-browser.cjs`. These development tools are not required by the deployed static site.
