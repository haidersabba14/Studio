#!/usr/bin/env python3
"""Prepare a dependency-free static site and read metadata from original packages.

Never executes or installs application files. Only bounded metadata entries are
read from ZIP archives. File presence alone never creates a download button.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import ipaddress
import json
import os
import plistlib
import re
import shutil
import struct
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
MAX_METADATA = 8 * 1024 * 1024
MAX_RESOURCES = 32 * 1024 * 1024
ANDROID_NS = '{http://schemas.android.com/apk/res/android}'


class PackageError(ValueError):
    pass


def require(data: bytes, offset: int, size: int) -> None:
    if offset < 0 or size < 0 or offset + size > len(data):
        raise PackageError('Truncated Android metadata')


def u16(data: bytes, offset: int) -> int:
    require(data, offset, 2)
    return struct.unpack_from('<H', data, offset)[0]


def u32(data: bytes, offset: int) -> int:
    require(data, offset, 4)
    return struct.unpack_from('<I', data, offset)[0]


def string_pool(data: bytes, start: int) -> list[str]:
    header_size, size = u16(data, start + 2), u32(data, start + 4)
    require(data, start, size)
    if header_size < 28:
        raise PackageError('Invalid Android string pool')
    count, flags, strings_start = u32(data, start + 8), u32(data, start + 16), u32(data, start + 20)
    if count > 200_000 or header_size + count * 4 > size:
        raise PackageError('Oversized Android string pool')
    end = start + size
    result = []
    for i in range(count):
        pos = start + strings_start + u32(data, start + header_size + i * 4)
        if pos >= end:
            raise PackageError('Invalid Android string offset')
        if flags & 0x100:
            def length8(p: int) -> tuple[int, int]:
                require(data, p, 1)
                n = data[p]
                if n & 0x80:
                    require(data, p + 1, 1)
                    return ((n & 0x7f) << 8) | data[p + 1], p + 2
                return n, p + 1
            _, pos = length8(pos)
            n, pos = length8(pos)
            if pos + n + 1 > end:
                raise PackageError('Invalid Android UTF-8 string')
            result.append(data[pos:pos + n].decode('utf-8'))
        else:
            n = u16(data, pos)
            pos += 2
            if n & 0x8000:
                n = ((n & 0x7fff) << 16) | u16(data, pos)
                pos += 2
            if pos + n * 2 + 2 > end:
                raise PackageError('Invalid Android UTF-16 string')
            result.append(data[pos:pos + n * 2].decode('utf-16-le'))
    return result


def pool_value(strings: list[str], index: int) -> str | None:
    if index == 0xffffffff:
        return None
    if index >= len(strings):
        raise PackageError('Invalid Android string index')
    return strings[index]


def parse_axml(data: bytes) -> dict[str, dict[str, object]]:
    if u16(data, 0) != 0x0003:
        raise PackageError('AndroidManifest.xml is not binary XML')
    total = u32(data, 4)
    require(data, 0, total)
    pos, strings, tags = u16(data, 2), [], {}
    while pos < total:
        require(data, pos, 8)
        kind, header_size, size = u16(data, pos), u16(data, pos + 2), u32(data, pos + 4)
        if size < 8 or header_size < 8 or header_size > size or pos + size > total:
            raise PackageError('Invalid Android XML chunk')
        if kind == 0x0001:
            strings = string_pool(data, pos)
        elif kind == 0x0102:
            ext = pos + header_size
            require(data, ext, 20)
            name = pool_value(strings, u32(data, ext + 4))
            attr_start, attr_size, count = u16(data, ext + 8), u16(data, ext + 10), u16(data, ext + 12)
            if attr_size < 20 or ext + attr_start + count * attr_size > pos + size:
                raise PackageError('Invalid Android XML attributes')
            attrs = {}
            for i in range(count):
                at = ext + attr_start + i * attr_size
                attr_name = pool_value(strings, u32(data, at + 4))
                raw = pool_value(strings, u32(data, at + 8))
                value_type, value = data[at + 15], u32(data, at + 16)
                if raw is not None:
                    parsed: object = raw
                elif value_type == 0x03:
                    parsed = pool_value(strings, value)
                elif value_type in (0x10, 0x11):
                    parsed = value
                elif value_type == 0x01:
                    parsed = {'resource': value}
                else:
                    parsed = None
                if attr_name:
                    attrs[attr_name] = parsed
            if name in ('manifest', 'uses-sdk'):
                tags[str(name)] = attrs
        pos += size
    if 'manifest' not in tags:
        raise PackageError('Missing Android manifest root')
    return tags


def resource_string(data: bytes, resource_id: int) -> str | None:
    """Resolve a simple default string resource used by versionName.

    Complex values, dynamic references, sparse/offset16 tables and only-localized
    values remain unknown instead of guessing a version.
    """
    if u16(data, 0) != 0x0002:
        return None
    total, start = u32(data, 4), u16(data, 2)
    require(data, 0, total)
    global_strings: list[str] = []
    package_id, type_id, entry_id = resource_id >> 24, (resource_id >> 16) & 255, resource_id & 65535
    while start < total:
        kind, header, size = u16(data, start), u16(data, start + 2), u32(data, start + 4)
        if size < 8 or start + size > total:
            raise PackageError('Invalid Android resources chunk')
        if kind == 0x0001:
            global_strings = string_pool(data, start)
        if kind == 0x0200 and u32(data, start + 8) == package_id:
            type_offset = u32(data, start + 284) if header >= 288 else 0
            pos = start + header
            while pos < start + size:
                child_kind, child_header, child_size = u16(data, pos), u16(data, pos + 2), u32(data, pos + 4)
                if child_size < 8 or pos + child_size > start + size:
                    raise PackageError('Invalid Android resource type')
                if child_kind == 0x0201 and data[pos + 8] + type_offset == type_id:
                    flags, count, entries_start = data[pos + 9], u32(data, pos + 12), u32(data, pos + 16)
                    config_size = u32(data, pos + 20)
                    require(data, pos + 20, config_size)
                    default_config = not any(data[pos + 24:pos + 20 + config_size])
                    if flags == 0 and default_config and entry_id < count:
                        table_pos = pos + child_header + entry_id * 4
                        if table_pos + 4 > pos + child_size:
                            raise PackageError('Invalid resource offset table')
                        entry_offset = u32(data, table_pos)
                        if entry_offset != 0xffffffff:
                            entry = pos + entries_start + entry_offset
                            require(data, entry, 8)
                            if not (u16(data, entry + 2) & 1):
                                value = entry + u16(data, entry)
                                require(data, value, 8)
                                if data[value + 3] == 0x03:
                                    return pool_value(global_strings, u32(data, value + 4))
                pos += child_size
        start += size
    return None


def checked_zip(path: Path) -> zipfile.ZipFile:
    archive = zipfile.ZipFile(path)
    infos = archive.infolist()
    if not infos or len(infos) > 100_000:
        archive.close()
        raise PackageError('Empty or oversized package archive')
    names = set()
    for info in infos:
        pure = PurePosixPath(info.filename.replace('\\', '/'))
        if pure.is_absolute() or '..' in pure.parts or info.filename in names or info.flag_bits & 1:
            archive.close()
            raise PackageError('Unsafe, duplicate or encrypted archive entry')
        names.add(info.filename)
    return archive


def bounded_read(archive: zipfile.ZipFile, name: str, limit: int = MAX_METADATA) -> bytes:
    info = archive.getinfo(name)
    if info.file_size > limit:
        raise PackageError(f'Oversized metadata entry: {name}')
    with archive.open(name) as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise PackageError('Metadata decompression limit exceeded')
    return data


def read_metadata(path: Path, platform: str) -> dict:
    with checked_zip(path) as archive:
        if platform == 'ios':
            candidates = [name for name in archive.namelist() if re.fullmatch(r'Payload/[^/]+\.app/Info\.plist', name)]
            if len(candidates) != 1:
                raise PackageError('Expected one primary iOS application Info.plist')
            info = plistlib.loads(bounded_read(archive, candidates[0]))
            if not isinstance(info, dict) or not info.get('CFBundleIdentifier'):
                raise PackageError('Missing iOS bundle identifier')
            executable = info.get('CFBundleExecutable')
            if not isinstance(executable, str) or '/' in executable or str(PurePosixPath(candidates[0]).parent / executable) not in archive.namelist():
                raise PackageError('Missing primary iOS executable')
            return {'version': text_value(info.get('CFBundleShortVersionString')), 'build': text_value(info.get('CFBundleVersion')),
                    'minOS': text_value(info.get('MinimumOSVersion')), 'packageId': text_value(info.get('CFBundleIdentifier'))}
        manifest = bounded_read(archive, 'AndroidManifest.xml')
        tags = parse_axml(manifest)
        info = tags['manifest']
        if not info.get('package'):
            raise PackageError('Missing Android package identifier')
        if not any(name.endswith('.dex') or name.startswith('lib/') for name in archive.namelist()):
            raise PackageError('Missing Android application code')
        version = info.get('versionName')
        if isinstance(version, dict) and 'resources.arsc' in archive.namelist():
            version = resource_string(bounded_read(archive, 'resources.arsc', MAX_RESOURCES), version['resource'])
        minimum = tags.get('uses-sdk', {}).get('minSdkVersion')
        version_code = info.get('versionCode')
        major = info.get('versionCodeMajor')
        if isinstance(major, int) and isinstance(version_code, int):
            version_code = (major << 32) | version_code
        return {'version': text_value(version), 'build': text_value(version_code),
                'minOS': f'API {minimum}' if isinstance(minimum, (str, int)) else None,
                'packageId': text_value(info.get('package'))}


def text_value(value: object) -> str | None:
    return str(value)[:512] if isinstance(value, (str, int, float)) and not isinstance(value, bool) else None


def digest_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def safe_https(value: object) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError('Expected HTTPS URL or null')
    parsed = urllib.parse.urlsplit(value)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.fragment:
        raise ValueError('Only direct HTTPS URLs without credentials or fragments are allowed')
    if parsed.port not in (None, 443):
        raise ValueError('HTTPS URLs must use port 443')
    hostname = parsed.hostname.lower()
    if hostname == 'localhost' or hostname.endswith(('.local', '.localhost')):
        raise ValueError('Local download endpoints are not allowed')
    try:
        if not ipaddress.ip_address(hostname).is_global:
            raise ValueError('Private download endpoints are not allowed')
    except ValueError as exc:
        if str(exc) == 'Private download endpoints are not allowed':
            raise
    return value


class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        safe_https(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def verify_external(url: str, size: int, sha256: str) -> None:
    safe_https(url)
    opener = urllib.request.build_opener(SafeRedirect())
    request = urllib.request.Request(url, headers={'User-Agent': 'HaiderStudio-ReleaseVerifier/1.0'})
    with opener.open(request, timeout=40) as response:
        advertised = response.headers.get('Content-Length')
        if advertised is not None and int(advertised) != size:
            raise PackageError('External file size differs from original')
        h, received = hashlib.sha256(), 0
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            received += len(chunk)
            if received > size:
                raise PackageError('External file exceeds original size')
            h.update(chunk)
        if received != size or h.hexdigest() != sha256:
            raise PackageError('External file SHA-256 differs from original')


def fetch_external_metadata(url: str, platform: str) -> dict:
    """Read the explicitly configured remote original without shipping it in Pages.

    This path makes Releases-hosted binaries usable from clean CI checkouts.
    A bounded temporary download is removed after reading its real metadata.
    """
    safe_https(url)
    opener = urllib.request.build_opener(SafeRedirect())
    request = urllib.request.Request(url, headers={'User-Agent': 'HaiderStudio-ReleaseVerifier/1.0'})
    maximum = 2 * 1024 * 1024 * 1024
    with tempfile.TemporaryDirectory(prefix='haider-package-') as temporary:
        path = Path(temporary) / ('original.ipa' if platform == 'ios' else 'original.apk')
        with opener.open(request, timeout=40) as response, path.open('wb') as output:
            advertised = response.headers.get('Content-Length')
            if advertised is not None and int(advertised) > maximum:
                raise PackageError('External package exceeds 2 GiB download limit')
            h, received = hashlib.sha256(), 0
            while True:
                data = response.read(1024 * 1024)
                if not data:
                    break
                received += len(data)
                if received > maximum:
                    raise PackageError('External package exceeds 2 GiB download limit')
                h.update(data)
                output.write(data)
            if advertised is not None and received != int(advertised):
                raise PackageError('External package transfer was incomplete')
        return {**read_metadata(path, platform), 'size': received, 'sha256': h.hexdigest()}


def js_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')


def read_studio_content(path: Path, source_ids: set[str]) -> dict:
    """Validate display copy only; application packages remain authoritative.

    Strings are plain text for the UI, never HTML or executable configuration.
    Absence of this optional file uses the built-in interface copy.
    """
    if not path.is_file():
        return {}
    content = json.loads(path.read_text(encoding='utf-8'))

    def object_keys(value: object, allowed: set[str], required: set[str], label: str) -> dict:
        if not isinstance(value, dict) or not set(value).issubset(allowed) or not required.issubset(value):
            raise ValueError('Invalid studio content fields: ' + label)
        return value

    def plain_text(value: object, maximum: int, label: str) -> None:
        if not isinstance(value, str) or len(value) > maximum or any(0xd800 <= ord(char) <= 0xdfff for char in value):
            raise ValueError('Invalid studio content text: ' + label)

    def localized(value: object, fields: set[str], label: str) -> None:
        translations = object_keys(value, {'ar', 'en'}, {'ar', 'en'}, label)
        for language, translation in translations.items():
            object_keys(translation, fields, fields, label + '.' + language)
            for field, text in translation.items():
                plain_text(text, 2000 if field == 'description' else 120, label + '.' + language + '.' + field)

    object_keys(content, {'schemaVersion', 'hero', 'montage', 'apps'}, {'schemaVersion'}, 'root')
    if type(content['schemaVersion']) is not int or content['schemaVersion'] != 1:
        raise ValueError('studio-content.json schemaVersion must be 1')
    if 'hero' in content:
        localized(content['hero'], {'title1', 'title2', 'description'}, 'hero')
    if 'montage' in content:
        localized(content['montage'], {'title', 'description'}, 'montage')
    if 'apps' in content:
        entries = object_keys(content['apps'], source_ids, set(), 'apps')
        for app_id, entry in entries.items():
            if not re.fullmatch(r'[a-z0-9][a-z0-9-]*', app_id):
                raise ValueError('Invalid studio content application ID')
            object_keys(entry, {'name', 'description'}, {'name', 'description'}, 'apps.' + app_id)
            plain_text(entry['name'], 120, 'apps.' + app_id + '.name')
            translations = object_keys(entry['description'], {'ar', 'en'}, {'ar', 'en'}, 'apps.' + app_id + '.description')
            for language, text in translations.items():
                plain_text(text, 2000, 'apps.' + app_id + '.description.' + language)
    return content


def base_path(config: dict, environ: dict) -> str:
    if config.get('siteUrl'):
        path = urllib.parse.urlsplit(config['siteUrl']).path
        return '/' + path.strip('/') + '/' if path.strip('/') else '/'
    repository = environ.get('GITHUB_REPOSITORY', '')
    if '/' in repository:
        name = repository.split('/', 1)[1]
        return '/' if name.lower().endswith('.github.io') else '/' + urllib.parse.quote(name, safe='') + '/'
    return './'


def build_site(root: Path, output: Path, strict: bool = False, environ: dict | None = None) -> tuple[list[dict], list[str]]:
    if output.resolve() == root.resolve() or root.resolve().is_relative_to(output.resolve()):
        raise ValueError('Output directory must be a child or sibling, not a parent of source')
    config = json.loads((root / 'config.json').read_text())
    environment = os.environ if environ is None else environ
    if config.get('siteUrl') is None:
        config['siteUrl'] = environment.get('HAIDER_SITE_URL') or None
    for key in ('contactEndpoint', 'siteUrl'):
        config[key] = safe_https(config.get(key))
    email = config.get('contactEmail')
    if email is not None and (not isinstance(email, str) or not re.fullmatch(r'[^\s<>@\r\n]+@[^\s<>@\r\n]+\.[^\s<>@\r\n]+', email)):
        raise ValueError('Invalid contactEmail')
    config['basePath'] = base_path(config, environment)
    sources = json.loads((root / 'apps.source.json').read_text())
    if not isinstance(sources, list):
        raise ValueError('apps.source.json must contain an application array')
    source_ids = set()
    for source in sources:
        if not isinstance(source, dict) or not isinstance(source.get('id'), str) or not re.fullmatch(r'[a-z0-9][a-z0-9-]*', source['id']):
            raise ValueError('Application IDs must match [a-z0-9][a-z0-9-]*')
        if source['id'] in source_ids:
            raise ValueError('Application IDs must be unique')
        source_ids.add(source['id'])
        filename = source.get('filename')
        if not isinstance(filename, str) or not filename or Path(filename).name != filename or '\\' in filename or source.get('platform') not in ('ios', 'android'):
            raise ValueError('Invalid app source filename or platform')
    studio_content = read_studio_content(root / 'assets' / 'studio-content.json', source_ids)
    external = config.get('externalDownloads', {})
    if not isinstance(external, dict) or any(key not in source_ids for key in external):
        raise ValueError('externalDownloads keys must reference declared application IDs')
    for key, value in external.items():
        external[key] = safe_https(value)
    pinned_hashes = config.get('externalSha256', {})
    if not isinstance(pinned_hashes, dict) or any(key not in source_ids or not isinstance(value, str) or not re.fullmatch(r'[a-fA-F0-9]{64}', value) for key, value in pinned_hashes.items()):
        raise ValueError('externalSha256 must map declared application IDs to SHA-256 hex digests')
    apps, errors = [], []
    for source in sources:
        app = {**source, 'available': False, 'version': None, 'build': None, 'minOS': None,
               'packageId': None, 'size': None, 'sha256': None, 'url': None, 'updatedAt': None}
        filename = source['filename']
        path = root / 'downloads' / filename
        remote = external.get(source['id'])
        if not path.is_file() and not remote:
            errors.append(f'{filename}: original file is missing; download remains disabled')
        else:
            try:
                if path.is_file():
                    metadata = read_metadata(path, source['platform'])
                    app.update(metadata)
                    app['size'], app['sha256'] = path.stat().st_size, digest_file(path)
                    if remote:
                        verify_external(remote, app['size'], app['sha256'])
                else:
                    app.update(fetch_external_metadata(remote, source['platform']))
                pinned = pinned_hashes.get(source['id'])
                if pinned and app['sha256'] != pinned.lower():
                    raise PackageError('Original file SHA-256 differs from configured externalSha256')
                if remote:
                    app['url'] = remote
                elif app['size'] > 100 * 1024 * 1024:
                    raise PackageError('File exceeds GitHub regular file limit; configure a verified external download URL')
                else:
                    app['url'] = 'downloads/' + urllib.parse.quote(filename)
                app['available'] = True
            except (PackageError, ValueError, OSError, KeyError, zipfile.BadZipFile, ET.ParseError, urllib.error.URLError, EOFError, plistlib.InvalidFileException) as exc:
                # URL failures never expose a stale, apparently working button.
                app['url'] = None
                reason = str(exc) if isinstance(exc, PackageError) else type(exc).__name__
                errors.append(f'{filename}: cannot enable download ({reason})')
        apps.append(app)
    public_config = {key: config.get(key) for key in ('contactEndpoint', 'contactEmail', 'siteUrl', 'basePath')}
    fingerprint = hashlib.sha256(json.dumps([{key: app.get(key) for key in ('id', 'version', 'build', 'sha256', 'available')} for app in apps], sort_keys=True).encode()).hexdigest()
    build_info = {'fingerprint': fingerprint, 'ready': bool(apps) and all(app['available'] for app in apps)}
    assets = root / 'assets'
    assets.mkdir(exist_ok=True)
    # A checked-in history survives deployment rebuilds and temporary missing
    # originals. Only newly verified real bytes can add entries; no build-time
    # timestamps are presented as publisher release dates. Historical URLs are
    # provenance only and never imply that an old download is still available.
    history_path = assets / 'releases.json'
    releases = json.loads(history_path.read_text()) if history_path.is_file() else []
    if not isinstance(releases, list):
        raise ValueError('assets/releases.json must be a release history array')
    release_fields = ('id', 'platform', 'version', 'build', 'size', 'sha256', 'filename', 'url')
    for release in releases:
        if not isinstance(release, dict) or any(field not in release for field in release_fields):
            raise ValueError('Invalid historical release record')
        if not isinstance(release['id'], str) or not re.fullmatch(r'[a-z0-9][a-z0-9-]*', release['id']) or release['platform'] not in ('ios', 'android') or not isinstance(release['sha256'], str) or not re.fullmatch(r'[a-f0-9]{64}', release['sha256']):
            raise ValueError('Invalid historical release identity')
        if not isinstance(release['size'], int) or isinstance(release['size'], bool) or release['size'] <= 0:
            raise ValueError('Invalid historical release file size')
    recorded = {(release['id'], release['sha256']) for release in releases}
    for app in apps:
        if app['available'] and (app['id'], app['sha256']) not in recorded:
            releases.append({field: app[field] for field in release_fields})
            recorded.add((app['id'], app['sha256']))
    history_path.write_text(json.dumps(releases, ensure_ascii=False, indent=2) + '\n')
    (assets / 'apps.json').write_text(json.dumps(apps, ensure_ascii=False, indent=2) + '\n')
    (assets / 'apps-data.js').write_text('window.HAIDER_APPS=' + js_json(apps) + ';\nwindow.HAIDER_BUILD=' + js_json(build_info) + ';\nwindow.HAIDER_RELEASES=' + js_json(releases) + ';\n')
    (assets / 'site-config.js').write_text('window.HAIDER_CONFIG=' + js_json(public_config) + ';\n')
    (assets / 'studio-content.js').write_text('window.HAIDER_CONTENT=' + js_json(studio_content) + ';\n')
    (assets / 'build-info.json').write_text(json.dumps(build_info, indent=2) + '\n')
    if output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True)
    for path in root.iterdir():
        if path.is_file() and (path.suffix == '.html' or path.name in ('.nojekyll', 'robots.txt', 'sitemap.xml', 'site.webmanifest')):
            shutil.copy2(path, output / path.name)
    for name in ('assets', 'apps'):
        if (root / name).is_dir():
            shutil.copytree(root / name, output / name, ignore=shutil.ignore_patterns('*.map', '.DS_Store'))
    # Additional catalog entries share a platform layout without modifying
    # checked-in templates. Explicit per-app pages always take precedence.
    for app in apps:
        detail_path = output / 'apps' / (app['id'] + '.html')
        template_path = root / 'apps' / (app['platform'] + '.html')
        if not detail_path.exists() and template_path.is_file():
            template = template_path.read_text()
            pattern = r'(<body\b[^>]*\bdata-app\s*=\s*["\'])' + re.escape(app['platform']) + r'(["\'])'
            page, replacements = re.subn(pattern, lambda match: match.group(1) + app['id'] + match.group(2), template, count=1, flags=re.IGNORECASE)
            if replacements != 1:
                raise ValueError('Platform detail template must declare body data-app')
            name = html.escape(str(app.get('name') or app['id']))
            platform_name = 'iOS' if app['platform'] == 'ios' else 'Android'
            title = '<title>' + name + ' · ' + platform_name + ' — تفاصيل التطبيق</title>'
            page, titles = re.subn(r'<title\b[^>]*>.*?</title>', lambda _: title, page, count=1, flags=re.IGNORECASE | re.DOTALL)
            if not titles:
                page = page.replace('</head>', title + '</head>', 1)
            description = '<meta name="description" content="' + html.escape('تفاصيل تطبيق ' + str(app.get('name') or app['id']) + ' لنظام ' + platform_name + '. بيانات ملف التطبيق وإرشادات التثبيت.', quote=True) + '">'
            page, descriptions = re.subn(r'<meta\b(?=[^>]*\bname\s*=\s*["\']description["\'])[^>]*>', lambda _: description, page, count=1, flags=re.IGNORECASE)
            if not descriptions:
                page = page.replace('</head>', description + '</head>', 1)
            page = re.sub(r'(<noscript>\s*<h1>).*?(</h1>)', lambda match: match.group(1) + name + ' · ' + platform_name + match.group(2), page, count=1, flags=re.IGNORECASE | re.DOTALL)
            detail_path.parent.mkdir(exist_ok=True)
            detail_path.write_text(page)
    (output / '.nojekyll').touch()
    for app in apps:
        if app['available'] and app['url'].startswith('downloads/'):
            (output / 'downloads').mkdir(exist_ok=True)
            shutil.copy2(root / 'downloads' / app['filename'], output / 'downloads' / app['filename'])
    error_page = output / '404.html'
    if error_page.exists():
        text = error_page.read_text().replace('__SITE_BASE__', config['basePath'])
        error_page.write_text(text)
    if config.get('siteUrl'):
        site = config['siteUrl'].rstrip('/') + '/'
        pages = [p.relative_to(output).as_posix() for p in output.rglob('*.html') if p.name != '404.html']
        from xml.sax.saxutils import escape
        sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        sitemap += ''.join('<url><loc>' + escape(urllib.parse.urljoin(site, p)) + '</loc></url>\n' for p in sorted(pages))
        (output / 'sitemap.xml').write_text(sitemap + '</urlset>\n')
        (output / 'robots.txt').write_text('User-agent: *\nAllow: /\nSitemap: ' + site + 'sitemap.xml\n')
        for page in output.rglob('*.html'):
            text = page.read_text()
            canonical = urllib.parse.urljoin(site, page.relative_to(output).as_posix())
            if page.name != '404.html' and 'rel="canonical"' not in text:
                text = text.replace('</head>', '<link rel="canonical" href="' + escape(canonical, {'"': '&quot;'}) + '">\n</head>')
                page.write_text(text)
    if strict and errors:
        raise PackageError('\n'.join(errors))
    return apps, errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--require-files', action='store_true', help='Fail if any original file is absent, invalid or unavailable')
    parser.add_argument('--root', type=Path, default=ROOT, help=argparse.SUPPRESS)
    parser.add_argument('--output', type=Path, help='Output directory (default: dist)')
    args = parser.parse_args()
    try:
        apps, errors = build_site(args.root, args.output or args.root / 'dist', args.require_files)
    except (ValueError, OSError) as exc:
        print(f'Build failed: {exc}', file=sys.stderr)
        return 1
    for warning in errors:
        print('NOTICE: ' + warning)
    print(f'Built static site: {sum(app["available"] for app in apps)}/{len(apps)} verified downloads enabled.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
