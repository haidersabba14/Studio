"""Meaningful release packaging checks; fixture applications are never shipped."""
import importlib.util
import hashlib
import copy
import io
import json
import plistlib
import shutil
import struct
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location('haider_build', Path(__file__).resolve().parents[1] / 'scripts' / 'build.py')
build = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(build)
SOURCE_ROOT = Path(__file__).resolve().parents[1]


def chunk(kind, header_size, content):
    return struct.pack('<HHI', kind, header_size, 8 + len(content)) + content


def make_axml(version='2.4.1', major=None):
    strings = ['manifest', 'package', 'studio.haider.android', 'versionName', version, 'versionCode', 'uses-sdk', 'minSdkVersion']
    if major is not None:
        strings.append('versionCodeMajor')
    encoded, offsets = b'', []
    for item in strings:
        val = item.encode('utf-8')
        offsets.append(len(encoded))
        encoded += bytes([len(item), len(val)]) + val + b'\0'
    encoded += b'\0' * (-len(encoded) % 4)
    pool = chunk(1, 28, struct.pack('<IIIII', len(strings), 0, 0x100, 28 + 4 * len(strings), 0) + struct.pack('<' + 'I' * len(strings), *offsets) + encoded)
    def attr(name, kind, value):
        return struct.pack('<IIIHBBI', 0xffffffff, strings.index(name), 0xffffffff, 8, 0, kind, value)
    def element(name, attrs):
        node_header = struct.pack('<II', 1, 0xffffffff)
        extension = struct.pack('<IIHHHHHH', 0xffffffff, strings.index(name), 20, 20, len(attrs), 0, 0, 0)
        return chunk(0x0102, 16, node_header + extension + b''.join(attrs))
    attrs = [attr('package', 3, 2), attr('versionName', 3, 4), attr('versionCode', 0x10, 24)]
    if major is not None:
        attrs.append(attr('versionCodeMajor', 0x10, major))
    elements = element('manifest', attrs) + element('uses-sdk', [attr('minSdkVersion', 0x10, 23)])
    return chunk(3, 8, pool + elements)


def ipa(path, info=None):
    info = info or {'CFBundleIdentifier': 'studio.haider.ios', 'CFBundleShortVersionString': '3.2.0', 'CFBundleVersion': '42', 'MinimumOSVersion': '14.0', 'CFBundleExecutable': 'Haider'}
    with zipfile.ZipFile(path, 'w') as archive:
        archive.writestr('Payload/Haider.app/Info.plist', plistlib.dumps(info, fmt=plistlib.FMT_BINARY))
        archive.writestr('Payload/Haider.app/Haider', b'fixture-only-code')


def apk(path, manifest=None):
    with zipfile.ZipFile(path, 'w') as archive:
        archive.writestr('AndroidManifest.xml', make_axml() if manifest is None else manifest)
        archive.writestr('classes.dex', b'fixture-only-code')


class BuildTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root / 'downloads').mkdir()
        for filename in ('config.json', 'apps.source.json'):
            shutil.copy2(SOURCE_ROOT / filename, self.root / filename)
        # Tests do not inherit operator-specific endpoints from a customized config.
        (self.root / 'config.json').write_text('{"contactEndpoint":null,"contactEmail":null,"siteUrl":null,"externalDownloads":{}}')
        # Only source declarations are copied. Every binary below is created
        # inside this isolated temporary tree; production packages are never read.
        self.sources_by_id = {source['id']: source for source in json.loads((self.root / 'apps.source.json').read_text())}
        self.fixture_paths = {app_id: self.root / 'downloads' / source['filename'] for app_id, source in self.sources_by_id.items()}
        (self.root / 'index.html').write_text('<html><head></head><body></body></html>')
        (self.root / '404.html').write_text('<base href="__SITE_BASE__">')

    def tearDown(self):
        self.temp.cleanup()

    def test_missing_originals_never_create_download_urls(self):
        apps, errors = build.build_site(self.root, self.root / 'dist', environ={})
        self.assertEqual(len(errors), 2)
        for app in apps:
            self.assertFalse(app['available'])
            for key in ('version', 'size', 'sha256', 'url'):
                self.assertIsNone(app[key])
        self.assertFalse((self.root / 'dist' / 'downloads').exists())
        with self.assertRaises(build.PackageError):
            build.build_site(self.root, self.root / 'dist', strict=True, environ={})

    def test_actual_binary_metadata_sizes_hashes_and_local_copy(self):
        ipa_path, apk_path = self.fixture_paths['ios'], self.fixture_paths['android']
        ipa(ipa_path)
        apk(apk_path)
        apps, errors = build.build_site(self.root, self.root / 'dist', strict=True, environ={})
        self.assertEqual(errors, [])
        self.assertEqual(apps[0]['version'], '3.2.0')
        self.assertEqual(apps[0]['build'], '42')
        self.assertEqual(apps[0]['minOS'], '14.0')
        self.assertEqual(apps[1]['version'], '2.4.1')
        self.assertEqual(apps[1]['build'], '24')
        self.assertEqual(apps[1]['minOS'], 'API 23')
        self.assertEqual(apps[1]['packageId'], 'studio.haider.android')
        for app in apps:
            path = self.root / 'downloads' / app['filename']
            self.assertEqual(app['size'], path.stat().st_size)
            self.assertEqual(app['sha256'], build.digest_file(path))
            self.assertEqual((self.root / 'dist/downloads' / app['filename']).read_bytes(), path.read_bytes())

    def test_fingerprint_stays_stable_and_changes_with_original(self):
        ipa(self.fixture_paths['ios'])
        apk(self.fixture_paths['android'])
        build.build_site(self.root, self.root / 'dist', environ={})
        previous = json.loads((self.root / 'assets/build-info.json').read_text())['fingerprint']
        build.build_site(self.root, self.root / 'dist', environ={})
        self.assertEqual(previous, json.loads((self.root / 'assets/build-info.json').read_text())['fingerprint'])
        apk(self.fixture_paths['android'], make_axml('2.5.0'))
        build.build_site(self.root, self.root / 'dist', environ={})
        self.assertNotEqual(previous, json.loads((self.root / 'assets/build-info.json').read_text())['fingerprint'])

    def test_malformed_and_unsafe_archives_disable_download(self):
        (self.fixture_paths['ios']).write_bytes(b'not an application')
        apk_path = self.fixture_paths['android']
        with zipfile.ZipFile(apk_path, 'w') as archive:
            archive.writestr('../escaped-file', 'bad')
        apps, errors = build.build_site(self.root, self.root / 'dist', environ={})
        self.assertTrue(all(not app['available'] and app['url'] is None for app in apps))
        self.assertEqual(len(errors), 2)
        self.assertFalse((self.root.parent / 'escaped-file').exists())

    def test_truncated_binary_manifest_is_rejected(self):
        apk(self.fixture_paths['android'], make_axml()[:-6])
        with self.assertRaises(build.PackageError):
            build.read_metadata(self.fixture_paths['android'], 'android')

    def test_oversized_metadata_is_rejected_without_extraction(self):
        with zipfile.ZipFile(self.fixture_paths['ios'], 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('Payload/Haider.app/Info.plist', b'A' * (build.MAX_METADATA + 1))
        with self.assertRaises(build.PackageError):
            build.read_metadata(self.fixture_paths['ios'], 'ios')

    def test_android_major_version_code_is_preserved(self):
        apk(self.fixture_paths['android'], make_axml(major=1))
        metadata = build.read_metadata(self.fixture_paths['android'], 'android')
        self.assertEqual(metadata['build'], str((1 << 32) | 24))

    def test_external_file_requires_matching_original(self):
        ipa(self.fixture_paths['ios'])
        config = {'externalDownloads': {'ios': 'https://example.org/' + self.sources_by_id['ios']['filename']}}
        (self.root / 'config.json').write_text(json.dumps(config))
        with patch.object(build, 'verify_external', side_effect=build.PackageError('mismatch')):
            apps, _ = build.build_site(self.root, self.root / 'dist', environ={})
            self.assertFalse(apps[0]['available'])
            self.assertIsNone(apps[0]['url'])
        with patch.object(build, 'verify_external') as verify:
            apps, _ = build.build_site(self.root, self.root / 'dist', environ={})
            self.assertTrue(apps[0]['available'])
            self.assertEqual(apps[0]['url'], config['externalDownloads']['ios'])
            self.assertFalse((self.root / 'dist/downloads' / self.sources_by_id['ios']['filename']).exists())
            verify.assert_called_once()

    def test_release_history_only_records_real_new_bytes_and_survives_missing_files(self):
        build.build_site(self.root, self.root / 'dist', environ={})
        history_path = self.root / 'assets/releases.json'
        self.assertEqual(json.loads(history_path.read_text()), [])
        ipa_path = self.fixture_paths['ios']
        ipa(ipa_path)
        apps, _ = build.build_site(self.root, self.root / 'dist', environ={})
        first_history = json.loads(history_path.read_text())
        self.assertEqual(len(first_history), 1)
        self.assertEqual(first_history[0]['sha256'], apps[0]['sha256'])
        self.assertEqual(first_history[0]['version'], '3.2.0')
        self.assertNotIn('updatedAt', first_history[0])
        build.build_site(self.root, self.root / 'dist', environ={})
        self.assertEqual(json.loads(history_path.read_text()), first_history)
        ipa(ipa_path, {'CFBundleIdentifier': 'studio.haider.ios', 'CFBundleShortVersionString': '3.3.0', 'CFBundleVersion': '43', 'MinimumOSVersion': '14.0', 'CFBundleExecutable': 'Haider'})
        build.build_site(self.root, self.root / 'dist', environ={})
        updated_history = json.loads(history_path.read_text())
        self.assertEqual(len(updated_history), 2)
        self.assertEqual(updated_history[1]['version'], '3.3.0')
        self.assertNotEqual(updated_history[0]['sha256'], updated_history[1]['sha256'])
        ipa_path.unlink()
        apps, _ = build.build_site(self.root, self.root / 'dist', environ={})
        self.assertFalse(apps[0]['available'])
        self.assertIsNone(apps[0]['url'])
        self.assertEqual(json.loads(history_path.read_text()), updated_history)
        self.assertEqual(json.loads((self.root / 'dist/assets/releases.json').read_text()), updated_history)
        self.assertIn('window.HAIDER_RELEASES=', (self.root / 'assets/apps-data.js').read_text())

    def test_release_history_does_not_influence_update_fingerprint(self):
        ipa(self.fixture_paths['ios'])
        build.build_site(self.root, self.root / 'dist', environ={})
        previous = json.loads((self.root / 'assets/build-info.json').read_text())['fingerprint']
        (self.root / 'assets/releases.json').write_text('[]')
        build.build_site(self.root, self.root / 'dist', environ={})
        self.assertEqual(previous, json.loads((self.root / 'assets/build-info.json').read_text())['fingerprint'])

    def test_external_only_original_works_in_clean_ci_and_pinned_hash_is_enforced(self):
        config = {'externalDownloads': {'ios': 'https://example.org/' + self.sources_by_id['ios']['filename']}, 'externalSha256': {'ios': 'a' * 64}}
        (self.root / 'config.json').write_text(json.dumps(config))
        metadata = {'version': '3.0.0', 'build': '8', 'minOS': '15.0', 'packageId': 'studio.haider.ios', 'size': 12345, 'sha256': 'a' * 64}
        with patch.object(build, 'fetch_external_metadata', return_value=metadata):
            apps, _ = build.build_site(self.root, self.root / 'dist', environ={})
            self.assertTrue(apps[0]['available'])
            self.assertEqual(apps[0]['sha256'], 'a' * 64)
            self.assertFalse((self.root / 'dist/downloads').exists())
        config['externalSha256']['ios'] = 'b' * 64
        (self.root / 'config.json').write_text(json.dumps(config))
        with patch.object(build, 'fetch_external_metadata', return_value=metadata):
            apps, _ = build.build_site(self.root, self.root / 'dist', environ={})
            self.assertFalse(apps[0]['available'])
            self.assertIsNone(apps[0]['url'])

    def test_streamed_remote_metadata_and_verification_read_actual_bytes(self):
        path = self.root / 'original.ipa'
        ipa(path)
        payload = path.read_bytes()
        class Response(io.BytesIO):
            def __init__(self, contents):
                super().__init__(contents)
                self.headers = {'Content-Length': str(len(contents))}
        class Opener:
            def open(self, request, timeout):
                return Response(payload)
        with patch.object(build.urllib.request, 'build_opener', return_value=Opener()):
            metadata = build.fetch_external_metadata('https://example.org/original.ipa', 'ios')
            self.assertEqual(metadata['version'], '3.2.0')
            self.assertEqual(metadata['size'], len(payload))
            self.assertEqual(metadata['sha256'], hashlib.sha256(payload).hexdigest())
            build.verify_external('https://example.org/original.ipa', len(payload), metadata['sha256'])
            with self.assertRaises(build.PackageError):
                build.verify_external('https://example.org/original.ipa', len(payload), 'b' * 64)

    def test_site_base_canonicals_and_sitemap(self):
        config = {'siteUrl': 'https://example.org/haider-studio/'}
        (self.root / 'config.json').write_text(json.dumps(config))
        build.build_site(self.root, self.root / 'dist', environ={})
        self.assertEqual((self.root / 'dist/404.html').read_text(), '<base href="/haider-studio/">')
        self.assertIn('https://example.org/haider-studio/index.html', (self.root / 'dist/sitemap.xml').read_text())
        self.assertIn('rel="canonical"', (self.root / 'dist/index.html').read_text())
        self.assertEqual(build.base_path({}, {'GITHUB_REPOSITORY': 'haider/studio'}), '/studio/')
        self.assertEqual(build.base_path({}, {'GITHUB_REPOSITORY': 'haider/haider.github.io'}), '/')

    def test_pages_site_url_fallback_generates_seo_without_modifying_source_config(self):
        source_config = (self.root / 'config.json').read_text()
        build.build_site(self.root, self.root / 'dist', environ={'HAIDER_SITE_URL': 'https://haider.github.io/studio'})
        self.assertIn('https://haider.github.io/studio/index.html', (self.root / 'dist/sitemap.xml').read_text())
        self.assertIn('href="https://haider.github.io/studio/index.html"', (self.root / 'dist/index.html').read_text())
        self.assertEqual((self.root / 'dist/404.html').read_text(), '<base href="/studio/">')
        self.assertEqual((self.root / 'config.json').read_text(), source_config)
        config = json.loads(source_config)
        config['siteUrl'] = 'https://custom.example.org/apps/'
        (self.root / 'config.json').write_text(json.dumps(config))
        build.build_site(self.root, self.root / 'dist', environ={'HAIDER_SITE_URL': 'https://haider.github.io/studio'})
        self.assertIn('https://custom.example.org/apps/index.html', (self.root / 'dist/sitemap.xml').read_text())
        self.assertNotIn('haider.github.io', (self.root / 'dist/sitemap.xml').read_text())
        config['siteUrl'] = None
        (self.root / 'config.json').write_text(json.dumps(config))
        with self.assertRaises(ValueError):
            build.build_site(self.root, self.root / 'dist', environ={'HAIDER_SITE_URL': 'http://insecure.example.org'})

    def test_third_application_generates_detail_page_and_preserves_platform_template(self):
        sources = json.loads((self.root / 'apps.source.json').read_text())
        sources.append({'id': 'studio-lite', 'platform': 'android', 'filename': 'studio-lite.apk', 'name': 'Studio Lite & Pro <test>', 'description': {'ar': 'تطبيق مرفق للاختبار', 'en': 'Test fixture application'}})
        (self.root / 'apps.source.json').write_text(json.dumps(sources))
        ipa(self.fixture_paths['ios'])
        apk(self.fixture_paths['android'])
        apk(self.root / 'downloads/studio-lite.apk', make_axml('1.7.2'))
        (self.root / 'apps').mkdir()
        template = '<html><head><title>Haider Studio</title><meta name="description" content="Platform application"></head><body data-page="details" data-app="android"><header>HAIDER STUDIO</header><main>Platform layout</main></body></html>'
        (self.root / 'apps/android.html').write_text(template)
        apps, errors = build.build_site(self.root, self.root / 'dist', strict=True, environ={})
        self.assertEqual(errors, [])
        self.assertEqual(len(apps), 3)
        self.assertTrue(apps[2]['available'])
        self.assertEqual(apps[2]['platform'], 'android')
        self.assertEqual(apps[2]['version'], '1.7.2')
        self.assertEqual((self.root / 'apps/android.html').read_text(), template)
        self.assertFalse((self.root / 'apps/studio-lite.html').exists())
        self.assertIn('data-app="studio-lite"', (self.root / 'dist/apps/studio-lite.html').read_text())
        generated = (self.root / 'dist/apps/studio-lite.html').read_text()
        self.assertIn('<title>Studio Lite &amp; Pro &lt;test&gt; · Android', generated)
        self.assertIn('content="تفاصيل تطبيق Studio Lite &amp; Pro &lt;test&gt; لنظام Android', generated)
        self.assertIn('<header>HAIDER STUDIO</header>', generated)
        self.assertEqual((self.root / 'dist/apps/android.html').read_text(), template)
        history = json.loads((self.root / 'assets/releases.json').read_text())
        self.assertEqual(history[2]['id'], 'studio-lite')
        self.assertEqual(history[2]['platform'], 'android')
        # Explicit application detail layouts override automatic generation.
        (self.root / 'apps/studio-lite.html').write_text('<body data-app="studio-lite">Custom layout</body>')
        config = {'externalDownloads': {'studio-lite': 'https://example.org/studio-lite.apk'}, 'externalSha256': {'studio-lite': apps[2]['sha256']}}
        (self.root / 'config.json').write_text(json.dumps(config))
        with patch.object(build, 'verify_external'):
            apps, errors = build.build_site(self.root, self.root / 'dist', strict=True, environ={})
        self.assertEqual(apps[2]['url'], 'https://example.org/studio-lite.apk')
        self.assertIn('Custom layout', (self.root / 'dist/apps/studio-lite.html').read_text())
        self.assertEqual(len(json.loads((self.root / 'assets/releases.json').read_text())), 3)

    def test_source_ids_must_be_safe_and_unique_and_external_keys_declared(self):
        original = json.loads((self.root / 'apps.source.json').read_text())
        for invalid in ('../escape', 'Unsafe', '-leading', '', 'white space', 'dots.app'):
            sources = [dict(original[0], id=invalid)]
            (self.root / 'apps.source.json').write_text(json.dumps(sources))
            with self.assertRaises(ValueError):
                build.build_site(self.root, self.root / 'dist', environ={})
        (self.root / 'apps.source.json').write_text(json.dumps([original[0], original[0]]))
        with self.assertRaises(ValueError):
            build.build_site(self.root, self.root / 'dist', environ={})
        (self.root / 'apps.source.json').write_text(json.dumps(original))
        (self.root / 'config.json').write_text(json.dumps({'externalDownloads': {'undeclared': 'https://example.org/app.apk'}}))
        with self.assertRaises(ValueError):
            build.build_site(self.root, self.root / 'dist', environ={})

    def studio_content_fixture(self):
        return {
            'schemaVersion': 1,
            'hero': {
                'ar': {'title1': 'مساحتك الإبداعية', 'title2': 'تبدأ هنا', 'description': 'اكتشف تطبيقات الاستوديو.'},
                'en': {'title1': 'Your creative space', 'title2': 'Starts here', 'description': 'Explore studio applications.'}
            },
            'montage': {
                'ar': {'title': 'المونتاج', 'description': 'مساحة محتوى المونتاج.'},
                'en': {'title': 'Montage', 'description': 'A space for montage content.'}
            },
            'apps': {'ios': {'name': 'Haider Studio', 'description': {'ar': 'وصف التطبيق', 'en': 'Application description'}}}
        }

    def write_studio_content(self, content):
        (self.root / 'assets').mkdir(exist_ok=True)
        path = self.root / 'assets/studio-content.json'
        path.write_text(json.dumps(content, ensure_ascii=False))
        return path

    def test_optional_studio_content_defaults_and_valid_localized_copy(self):
        build.build_site(self.root, self.root / 'dist', environ={})
        self.assertEqual((self.root / 'assets/studio-content.js').read_text(), 'window.HAIDER_CONTENT={};\n')
        content = self.studio_content_fixture()
        path = self.write_studio_content(content)
        build.build_site(self.root, self.root / 'dist', environ={})
        script = (self.root / 'dist/assets/studio-content.js').read_text()
        self.assertEqual(json.loads(script.removeprefix('window.HAIDER_CONTENT=').removesuffix(';\n')), content)
        self.assertEqual(json.loads(path.read_text()), content)
        # Display configuration cannot alter authoritative package metadata.
        apps = json.loads((self.root / 'assets/apps.json').read_text())
        self.assertIsNone(apps[0]['url'])
        self.assertIsNone(apps[0]['version'])
        content['apps']['studio-lite'] = {'name': 'Studio Lite', 'description': {'ar': 'وصف', 'en': 'Description'}}
        self.write_studio_content(content)
        self.assertEqual(build.read_studio_content(path, {'ios', 'android', 'studio-lite'}), content)

    def test_studio_content_rejects_malformed_unknown_or_non_text_fields(self):
        valid = self.studio_content_fixture()
        mutations = []
        for version in (True, 2, '1', None):
            value = copy.deepcopy(valid)
            value['schemaVersion'] = version
            mutations.append(value)
        value = copy.deepcopy(valid)
        value['downloadUrl'] = 'https://example.org/fake.ipa'
        mutations.append(value)
        value = copy.deepcopy(valid)
        value['hero']['ar']['script'] = 'alert(1)'
        mutations.append(value)
        value = copy.deepcopy(valid)
        value['hero']['ar']['title1'] = {'html': 'unsupported'}
        mutations.append(value)
        value = copy.deepcopy(valid)
        value['hero']['ar']['title1'] = 'x' * 121
        mutations.append(value)
        value = copy.deepcopy(valid)
        value['montage']['en']['description'] = 'x' * 2001
        mutations.append(value)
        value = copy.deepcopy(valid)
        value['apps']['ios']['name'] = 'x' * 121
        mutations.append(value)
        value = copy.deepcopy(valid)
        value['apps']['ios']['description']['en'] = ['unsupported']
        mutations.append(value)
        value = copy.deepcopy(valid)
        value['apps']['ios']['sha256'] = 'a' * 64
        mutations.append(value)
        value = copy.deepcopy(valid)
        value['apps']['undeclared'] = value['apps']['ios']
        mutations.append(value)
        value = copy.deepcopy(valid)
        del value['hero']['en']
        mutations.append(value)
        mutations.extend([[], {}, None])
        for index, content in enumerate(mutations):
            with self.subTest(index=index):
                self.write_studio_content(content)
                with self.assertRaises(ValueError):
                    build.build_site(self.root, self.root / 'dist', environ={})
        path = self.write_studio_content(valid)
        path.write_text('{ malformed json')
        with self.assertRaises(ValueError):
            build.build_site(self.root, self.root / 'dist', environ={})

    def test_studio_content_script_characters_stay_plain_text_and_are_escaped(self):
        content = self.studio_content_fixture()
        payload = '</script><script>alert("test")</script> & text'
        content['hero']['ar']['description'] = payload
        content['apps']['ios']['name'] = payload
        path = self.write_studio_content(content)
        build.build_site(self.root, self.root / 'dist', environ={})
        script = (self.root / 'dist/assets/studio-content.js').read_text()
        self.assertNotIn('<', script)
        self.assertNotIn('</script>', script)
        self.assertIn('\\u003c/script>', script)
        parsed = json.loads(script.removeprefix('window.HAIDER_CONTENT=').removesuffix(';\n'))
        self.assertEqual(parsed['hero']['ar']['description'], payload)
        self.assertEqual(parsed['apps']['ios']['name'], payload)
        self.assertEqual(json.loads(path.read_text())['apps']['ios']['name'], payload)

    def test_unsafe_urls_and_script_injection_are_rejected(self):
        for value in ('javascript:alert(1)', 'http://example.org/file', 'https://user:password@example.org/file', 'https://localhost/file', 'https://127.0.0.1/file'):
            with self.assertRaises(ValueError):
                build.safe_https(value)
        self.assertNotIn('</script>', build.js_json({'text': '</script><script>alert(1)</script>'}))


if __name__ == '__main__':
    unittest.main()
