# Haider Studio

موقع تحميل أسود وذهبي يعمل على GitHub Pages.

## النشر
1. أنشئ مستودع GitHub عامًا وارفع `index.html` ومجلد `downloads` بمحتوياته (لا ترفع ZIP وحده).
2. من Settings > Pages اختر Deploy from a branch، ثم `main` و`/(root)` واضغط Save.
3. افتح الرابط الذي تعرضه GitHub Pages بعد اكتمال النشر.

> ملف IPA يحتاج طريقة تثبيت وتوقيع مناسبة على iPhone، ورابط GitHub Pages لا يثبته تلقائيًا.
